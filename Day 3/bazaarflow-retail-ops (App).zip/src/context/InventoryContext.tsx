import React, { createContext, useCallback, useContext, useEffect, useReducer } from 'react';
import { INITIAL_INVENTORY, INITIAL_SHRINKAGE_LOG } from '../data/initialInventory';
import {
  AppMode,
  InventoryFilters,
  ShrinkageEntry,
  ShrinkageReason,
  SKU,
  StaffTab,
  ToastMessage,
} from '../types/inventory';
import { getRecommendedOrderQty, getStockStatus } from '../utils/inventoryMath';

const STORAGE_KEY = 'bazaarflow_store_ops_v1';

interface PersistedData {
  skus: SKU[];
  shrinkageLog: ShrinkageEntry[];
}

interface InventoryState {
  skus: SKU[];
  shrinkageLog: ShrinkageEntry[];
  mode: AppMode;
  activeTab: StaffTab;
  filters: InventoryFilters;
  toasts: ToastMessage[];
  shrinkageModalOpen: boolean;
  shrinkageTargetSkuId: string | null;
}

const DEFAULT_FILTERS: InventoryFilters = {
  search: '',
  category: 'All',
  status: 'All',
  abc: 'All',
  ved: 'All',
};

function loadInitialData(): PersistedData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as PersistedData;
      if (Array.isArray(parsed.skus) && parsed.skus.length > 0) {
        return {
          skus: parsed.skus,
          shrinkageLog: Array.isArray(parsed.shrinkageLog) ? parsed.shrinkageLog : INITIAL_SHRINKAGE_LOG,
        };
      }
    }
  } catch {
    // Fallback to initial dataset if storage is unavailable or corrupted
  }
  return {
    skus: INITIAL_INVENTORY,
    shrinkageLog: INITIAL_SHRINKAGE_LOG,
  };
}

type Action =
  | { type: 'SET_MODE'; mode: AppMode }
  | { type: 'SET_TAB'; tab: StaffTab }
  | { type: 'SET_FILTERS'; filters: Partial<InventoryFilters> }
  | { type: 'RESET_FILTERS' }
  | { type: 'RECORD_SALE'; skuId: string }
  | { type: 'RESTOCK_SHELF'; skuId: string }
  | { type: 'CREATE_DC_ORDER'; skuId: string; quantity: number; leadTimeWindow: '24 hrs' | '48 hrs'; orderId: string }
  | { type: 'BULK_DC_ORDER'; orderItems: Array<{ skuId: string; quantity: number; leadTimeWindow: '24 hrs' | '48 hrs'; orderId: string }> }
  | { type: 'RECEIVE_DC_SHIPMENT'; skuId: string; quantity: number }
  | { type: 'LOG_SHRINKAGE'; entry: ShrinkageEntry }
  | { type: 'OPEN_SHRINKAGE_MODAL'; skuId: string | null }
  | { type: 'CLOSE_SHRINKAGE_MODAL' }
  | { type: 'ADD_TOAST'; toast: ToastMessage }
  | { type: 'DISMISS_TOAST'; id: string }
  | { type: 'RESET_DATA' };

function inventoryReducer(state: InventoryState, action: Action): InventoryState {
  switch (action.type) {
    case 'SET_MODE':
      return { ...state, mode: action.mode };
    case 'SET_TAB':
      return { ...state, activeTab: action.tab };
    case 'SET_FILTERS':
      return { ...state, filters: { ...state.filters, ...action.filters } };
    case 'RESET_FILTERS':
      return { ...state, filters: DEFAULT_FILTERS };
    case 'RECORD_SALE':
      return {
        ...state,
        skus: state.skus.map((sku) =>
          sku.id === action.skuId && sku.shelfStock > 0
            ? { ...sku, shelfStock: sku.shelfStock - 1 }
            : sku
        ),
      };
    case 'RESTOCK_SHELF':
      return {
        ...state,
        skus: state.skus.map((sku) => {
          if (sku.id !== action.skuId || sku.backroomStock <= 0) return sku;
          const roomOnShelf = Math.max(0, sku.shelfCapacity - sku.shelfStock);
          const transferQty = Math.min(sku.backroomStock, roomOnShelf > 0 ? Math.min(6, roomOnShelf) : 6);
          return {
            ...sku,
            shelfStock: sku.shelfStock + transferQty,
            backroomStock: sku.backroomStock - transferQty,
          };
        }),
      };
    case 'CREATE_DC_ORDER':
      return {
        ...state,
        skus: state.skus.map((sku) =>
          sku.id === action.skuId
            ? {
                ...sku,
                inTransit: true,
                inTransitQty: sku.inTransitQty + action.quantity,
                dcOrderId: action.orderId,
                dcLeadTimeWindow: action.leadTimeWindow,
                orderedAt: 'Just now',
              }
            : sku
        ),
      };
    case 'BULK_DC_ORDER': {
      const orderMap = new Map(action.orderItems.map((item) => [item.skuId, item]));
      return {
        ...state,
        skus: state.skus.map((sku) => {
          const item = orderMap.get(sku.id);
          if (!item) return sku;
          return {
            ...sku,
            inTransit: true,
            inTransitQty: sku.inTransitQty + item.quantity,
            dcOrderId: item.orderId,
            dcLeadTimeWindow: item.leadTimeWindow,
            orderedAt: 'Just now',
          };
        }),
      };
    }
    case 'RECEIVE_DC_SHIPMENT':
      return {
        ...state,
        skus: state.skus.map((sku) => {
          if (sku.id !== action.skuId) return sku;
          const addToShelf = sku.shelfStock === 0 ? Math.min(action.quantity, Math.max(6, Math.floor(sku.shelfCapacity * 0.5))) : 0;
          const addToBackroom = action.quantity - addToShelf;
          return {
            ...sku,
            shelfStock: sku.shelfStock + addToShelf,
            backroomStock: sku.backroomStock + addToBackroom,
            inTransit: false,
            inTransitQty: 0,
            dcOrderId: undefined,
            dcLeadTimeWindow: undefined,
            orderedAt: undefined,
          };
        }),
      };
    case 'LOG_SHRINKAGE':
      return {
        ...state,
        skus: state.skus.map((sku) => {
          if (sku.id !== action.entry.skuId) return sku;
          if (action.entry.location === 'Shelf') {
            return { ...sku, shelfStock: Math.max(0, sku.shelfStock - action.entry.quantity) };
          }
          return { ...sku, backroomStock: Math.max(0, sku.backroomStock - action.entry.quantity) };
        }),
        shrinkageLog: [action.entry, ...state.shrinkageLog],
        shrinkageModalOpen: false,
        shrinkageTargetSkuId: null,
      };
    case 'OPEN_SHRINKAGE_MODAL':
      return { ...state, shrinkageModalOpen: true, shrinkageTargetSkuId: action.skuId };
    case 'CLOSE_SHRINKAGE_MODAL':
      return { ...state, shrinkageModalOpen: false, shrinkageTargetSkuId: null };
    case 'ADD_TOAST':
      return { ...state, toasts: [...state.toasts.slice(-3), action.toast] };
    case 'DISMISS_TOAST':
      return { ...state, toasts: state.toasts.filter((t) => t.id !== action.id) };
    case 'RESET_DATA':
      return {
        ...state,
        skus: INITIAL_INVENTORY,
        shrinkageLog: INITIAL_SHRINKAGE_LOG,
        filters: DEFAULT_FILTERS,
      };
    default:
      return state;
  }
}

interface InventoryContextValue {
  state: InventoryState;
  setMode: (mode: AppMode) => void;
  setTab: (tab: StaffTab) => void;
  setFilters: (filters: Partial<InventoryFilters>) => void;
  resetFilters: () => void;
  navigateToTrackerWithFilter: (filters: Partial<InventoryFilters>) => void;
  recordSale: (skuId: string) => void;
  restockShelf: (skuId: string) => void;
  createDCOrder: (skuId: string, customQty?: number) => void;
  bulkOrderReplenishment: () => void;
  receiveDCShipment: (skuId: string) => void;
  logShrinkage: (params: {
    skuId: string;
    location: 'Shelf' | 'Backroom';
    quantity: number;
    reason: ShrinkageReason;
    note: string;
    loggedBy: string;
  }) => void;
  openShrinkageModal: (skuId?: string) => void;
  closeShrinkageModal: () => void;
  dismissToast: (id: string) => void;
  resetDemoData: () => void;
}

const InventoryContext = createContext<InventoryContextValue | null>(null);

export const InventoryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const initial = loadInitialData();
  const [state, dispatch] = useReducer(inventoryReducer, {
    skus: initial.skus,
    shrinkageLog: initial.shrinkageLog,
    mode: 'staff',
    activeTab: 'overview',
    filters: DEFAULT_FILTERS,
    toasts: [],
    shrinkageModalOpen: false,
    shrinkageTargetSkuId: null,
  });

  useEffect(() => {
    try {
      const payload: PersistedData = {
        skus: state.skus,
        shrinkageLog: state.shrinkageLog,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch {
      // Ignore storage quota errors
    }
  }, [state.skus, state.shrinkageLog]);

  const pushToast = useCallback((toast: Omit<ToastMessage, 'id'>) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    dispatch({ type: 'ADD_TOAST', toast: { ...toast, id } });
    window.setTimeout(() => {
      dispatch({ type: 'DISMISS_TOAST', id });
    }, 3200);
  }, []);

  const setMode = useCallback((mode: AppMode) => {
    dispatch({ type: 'SET_MODE', mode });
  }, []);

  const setTab = useCallback((tab: StaffTab) => {
    dispatch({ type: 'SET_TAB', tab });
  }, []);

  const setFilters = useCallback((filters: Partial<InventoryFilters>) => {
    dispatch({ type: 'SET_FILTERS', filters });
  }, []);

  const resetFilters = useCallback(() => {
    dispatch({ type: 'RESET_FILTERS' });
  }, []);

  const navigateToTrackerWithFilter = useCallback((filters: Partial<InventoryFilters>) => {
    dispatch({ type: 'RESET_FILTERS' });
    dispatch({ type: 'SET_FILTERS', filters });
    dispatch({ type: 'SET_TAB', tab: 'tracker' });
  }, []);

  const recordSale = useCallback(
    (skuId: string) => {
      const target = state.skus.find((s) => s.id === skuId);
      if (!target) return;
      if (target.shelfStock <= 0) {
        pushToast({
          title: `Shelf empty for ${target.name}`,
          detail: target.backroomStock > 0 ? 'Tap +Restock Shelf to pull units from backroom.' : 'Order DC restock immediately.',
          tone: 'warning',
        });
        return;
      }
      dispatch({ type: 'RECORD_SALE', skuId });
      const remaining = target.shelfStock - 1;
      pushToast({
        title: `Sale recorded (-1) · ${target.skuCode}`,
        detail: `${target.name} · ${remaining} left on shelf`,
        tone: remaining === 0 ? 'warning' : 'success',
      });
    },
    [state.skus, pushToast]
  );

  const restockShelf = useCallback(
    (skuId: string) => {
      const target = state.skus.find((s) => s.id === skuId);
      if (!target) return;
      if (target.backroomStock <= 0) {
        pushToast({
          title: `No backroom stock · ${target.skuCode}`,
          detail: 'Raise a DC Transfer Order to replenish backroom.',
          tone: 'warning',
        });
        return;
      }
      const roomOnShelf = Math.max(0, target.shelfCapacity - target.shelfStock);
      const transferQty = Math.min(target.backroomStock, roomOnShelf > 0 ? Math.min(6, roomOnShelf) : 6);
      dispatch({ type: 'RESTOCK_SHELF', skuId });
      pushToast({
        title: `Shelf replenished (+${transferQty})`,
        detail: `${target.name} moved from Backroom to ${target.aisle}`,
        tone: 'success',
      });
    },
    [state.skus, pushToast]
  );

  const createDCOrder = useCallback(
    (skuId: string, customQty?: number) => {
      const target = state.skus.find((s) => s.id === skuId);
      if (!target) return;
      const qty = customQty ?? getRecommendedOrderQty(target);
      const orderId = `DC-${Math.floor(1000 + Math.random() * 9000)}`;
      const leadTimeWindow: '24 hrs' | '48 hrs' = target.leadTimeDays <= 2 ? '24 hrs' : '48 hrs';
      dispatch({ type: 'CREATE_DC_ORDER', skuId, quantity: qty, leadTimeWindow, orderId });
      pushToast({
        title: `DC Transfer #${orderId} raised`,
        detail: `${qty} units of ${target.name} · ETA ${leadTimeWindow}`,
        tone: 'info',
      });
    },
    [state.skus, pushToast]
  );

  const bulkOrderReplenishment = useCallback(() => {
    const eligible = state.skus.filter((sku) => {
      const status = getStockStatus(sku);
      return (status === 'Out of Stock' || status === 'Critical' || status === 'Low Stock') && !sku.inTransit;
    });
    if (eligible.length === 0) {
      pushToast({
        title: 'All low-stock SKUs already in transit',
        detail: 'No additional DC transfer requests needed.',
        tone: 'info',
      });
      return;
    }
    const orderItems = eligible.map((sku) => ({
      skuId: sku.id,
      quantity: getRecommendedOrderQty(sku),
      leadTimeWindow: (sku.leadTimeDays <= 2 ? '24 hrs' : '48 hrs') as '24 hrs' | '48 hrs',
      orderId: `DC-${Math.floor(1000 + Math.random() * 9000)}`,
    }));
    dispatch({ type: 'BULK_DC_ORDER', orderItems });
    pushToast({
      title: `Bulk DC replenishment raised (${eligible.length} SKUs)`,
      detail: 'All eligible Critical & Low Stock items marked In Transit.',
      tone: 'info',
    });
  }, [state.skus, pushToast]);

  const receiveDCShipment = useCallback(
    (skuId: string) => {
      const target = state.skus.find((s) => s.id === skuId);
      if (!target) return;
      const qty = target.inTransit && target.inTransitQty > 0 ? target.inTransitQty : getRecommendedOrderQty(target);
      dispatch({ type: 'RECEIVE_DC_SHIPMENT', skuId, quantity: qty });
      pushToast({
        title: `DC Shipment received (+${qty})`,
        detail: `${target.name} stocked & ready for floor`,
        tone: 'success',
      });
    },
    [state.skus, pushToast]
  );

  const logShrinkage = useCallback(
    (params: {
      skuId: string;
      location: 'Shelf' | 'Backroom';
      quantity: number;
      reason: ShrinkageReason;
      note: string;
      loggedBy: string;
    }) => {
      const target = state.skus.find((s) => s.id === params.skuId);
      if (!target) return;
      const available = params.location === 'Shelf' ? target.shelfStock : target.backroomStock;
      const actualQty = Math.min(params.quantity, available);
      if (actualQty <= 0) {
        pushToast({
          title: `Cannot log shrinkage on empty ${params.location.toLowerCase()}`,
          detail: `${target.name} has 0 units in ${params.location}.`,
          tone: 'warning',
        });
        return;
      }
      const entry: ShrinkageEntry = {
        id: `shk-${Date.now()}`,
        skuId: target.id,
        skuCode: target.skuCode,
        productName: target.name,
        category: target.category,
        location: params.location,
        quantity: actualQty,
        unitCost: target.unitCost,
        totalLossValue: actualQty * target.unitCost,
        reason: params.reason,
        note: params.note.trim() || 'Floor audit adjustment',
        timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) + ', Today',
        loggedBy: params.loggedBy.trim() || 'Store Manager',
      };
      dispatch({ type: 'LOG_SHRINKAGE', entry });
      pushToast({
        title: `Shrinkage logged (-${actualQty} units)`,
        detail: `${target.name} · ${params.reason}`,
        tone: 'danger',
      });
    },
    [state.skus, pushToast]
  );

  const openShrinkageModal = useCallback((skuId?: string) => {
    dispatch({ type: 'OPEN_SHRINKAGE_MODAL', skuId: skuId ?? null });
  }, []);

  const closeShrinkageModal = useCallback(() => {
    dispatch({ type: 'CLOSE_SHRINKAGE_MODAL' });
  }, []);

  const dismissToast = useCallback((id: string) => {
    dispatch({ type: 'DISMISS_TOAST', id });
  }, []);

  const resetDemoData = useCallback(() => {
    dispatch({ type: 'RESET_DATA' });
    pushToast({
      title: 'Store inventory reset to baseline',
      detail: 'Restored 28 active SKUs and baseline shrinkage ledger.',
      tone: 'info',
    });
  }, [pushToast]);

  return (
    <InventoryContext.Provider
      value={{
        state,
        setMode,
        setTab,
        setFilters,
        resetFilters,
        navigateToTrackerWithFilter,
        recordSale,
        restockShelf,
        createDCOrder,
        bulkOrderReplenishment,
        receiveDCShipment,
        logShrinkage,
        openShrinkageModal,
        closeShrinkageModal,
        dismissToast,
        resetDemoData,
      }}
    >
      {children}
    </InventoryContext.Provider>
  );
};

export function useInventory() {
  const ctx = useContext(InventoryContext);
  if (!ctx) {
    throw new Error('useInventory must be used inside InventoryProvider');
  }
  return ctx;
}
