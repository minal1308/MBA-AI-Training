import React from 'react';
import { AlertCircle, AlertTriangle, CheckCircle2, Truck, XCircle } from 'lucide-react';
import { StockStatus } from '../types/inventory';

interface StatusBadgeProps {
  status: StockStatus;
  inTransit?: boolean;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, inTransit }) => {
  const styles: Record<StockStatus, string> = {
    Optimal: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'Low Stock': 'bg-amber-50 text-amber-800 border-amber-200',
    Critical: 'bg-rose-50 text-rose-700 border-rose-200',
    'Out of Stock': 'bg-rose-100 text-rose-800 border-rose-300',
  };

  const Icon =
    status === 'Optimal'
      ? CheckCircle2
      : status === 'Low Stock'
        ? AlertTriangle
        : status === 'Critical'
          ? AlertCircle
          : XCircle;

  return (
    <div className="inline-flex flex-wrap items-center gap-1.5">
      <span
        className={`inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium rounded-md border whitespace-nowrap ${styles[status]}`}
      >
        <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
        <span>{status}</span>
      </span>
      {inTransit && (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium rounded-md border bg-sky-50 text-sky-700 border-sky-200 whitespace-nowrap">
          <Truck className="w-3 h-3 shrink-0" aria-hidden="true" />
          <span>In Transit</span>
        </span>
      )}
    </div>
  );
};
