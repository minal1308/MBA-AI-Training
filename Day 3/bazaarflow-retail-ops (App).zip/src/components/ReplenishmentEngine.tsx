import React, { useMemo, useState } from 'react';
import { CheckCircle2, Clock, PackageCheck, Truck } from 'lucide-react';
import { useInventory } from '../context/InventoryContext';
import {
  calculateROP,
  formatINR,
  getDaysOfCover,
  getRecommendedOrderQty,
  getStockStatus,
  getTotalStock,
} from '../utils/inventoryMath';
import { StatusBadge } from './StatusBadge';

export const ReplenishmentEngine: React.FC = () => {
  const { state, createDCOrder, bulkOrderReplenishment, receiveDCShipment } = useInventory();
  const [customQtys, setCustomQtys] = useState<Record<string, number>>({});

  const { actionQueue, inTransitItems, totalEstOrderCost, eligibleCount } = useMemo(() => {
    const queue = state.skus
      .filter((sku) => {
        const status = getStockStatus(sku);
        return (status !== 'Optimal' || sku.inTransit) && !sku.inTransit;
      })
      .sort((a, b) => {
        const priority = { 'Out of Stock': 0, Critical: 1, 'Low Stock': 2, Optimal: 3 };
        const pa = priority[getStockStatus(a)];
        const pb = priority[getStockStatus(b)];
        if (pa !== pb) return pa - pb;
        return getDaysOfCover(a) - getDaysOfCover(b);
      });

    const transit = state.skus.filter((sku) => sku.inTransit);

    const cost = queue.reduce((sum, sku) => {
      const qty = customQtys[sku.id] ?? getRecommendedOrderQty(sku);
      return sum + qty * sku.unitCost;
    }, 0);

    return {
      actionQueue: queue,
      inTransitItems: transit,
      totalEstOrderCost: cost,
      eligibleCount: queue.length,
    };
  }, [state.skus, customQtys]);

  const handleQtyChange = (skuId: string, val: string) => {
    const num = Math.max(1, parseInt(val, 10) || 1);
    setCustomQtys((prev) => ({ ...prev, [skuId]: num }));
  };

  return (
    <div className="space-y-6">
      {/* Header & Bulk Action */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Smart Replenishment & Reorder Engine
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            ROP = (Average Daily Sales × Lead Time) + Safety Stock · Automated DC Transfer Orders (24–48 hr SLA)
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          {eligibleCount > 0 && (
            <div className="text-right hidden sm:block">
              <p className="text-xs text-slate-500">Queue Estimate ({eligibleCount} SKUs)</p>
              <p className="text-sm font-mono font-semibold text-slate-900 tabular-nums">
                {formatINR(totalEstOrderCost)}
              </p>
            </div>
          )}
          <button
            type="button"
            onClick={bulkOrderReplenishment}
            disabled={eligibleCount === 0}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap cursor-pointer"
          >
            <Truck className="w-4 h-4" aria-hidden="true" />
            <span>Order All Eligible ({eligibleCount})</span>
          </button>
        </div>
      </div>

      {/* Formula & Policy Summary Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Low Stock Trigger</p>
          <p className="mt-1 text-sm font-semibold text-slate-900">Total Stock ≤ Reorder Point</p>
          <p className="mt-1 text-xs text-slate-500">
            Flags SKU for central Distribution Centre (DC) replenishment before safety buffer depletes.
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Critical Vital Alert</p>
          <p className="mt-1 text-sm font-semibold text-rose-700">
            Vital (V) SKU &lt; 50% of ROP
          </p>
          <p className="mt-1 text-xs text-slate-500">
            High-velocity staples prioritized for 24-hour express DC dispatch slot.
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Active In-Transit Shipments</p>
          <p className="mt-1 text-sm font-semibold font-mono tabular-nums text-sky-700">
            {inTransitItems.length} DC Transfer Orders
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Mark shipments received upon unloading at store backroom bay.
          </p>
        </div>
      </div>

      {/* In Transit DC Transfer Orders */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              In-Transit from Distribution Centre ({inTransitItems.length})
            </h2>
            <p className="text-xs text-slate-500">
              Active DC transfer requests scheduled within 24–48 hours
            </p>
          </div>
        </div>

        {inTransitItems.length === 0 ? (
          <div className="p-6 text-center text-sm text-slate-500">
            No active DC shipments in transit. Raise transfer orders from the reorder queue below.
          </div>
        ) : (
          <div className="divide-y divide-slate-200">
            {inTransitItems.map((sku) => {
              const status = getStockStatus(sku);
              return (
                <div
                  key={sku.id}
                  className="px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70"
                >
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-mono font-semibold text-sky-700 bg-sky-50 border border-sky-200 px-2 py-0.5 rounded-md">
                        #{sku.dcOrderId ?? 'DC-4092'}
                      </span>
                      <span className="text-sm font-semibold text-slate-900">{sku.name}</span>
                      <span className="text-xs text-slate-500 font-mono">
                        {sku.skuCode} · {sku.packSize}
                      </span>
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-3 text-xs text-slate-600 tabular-nums">
                      <span className="inline-flex items-center gap-1 font-medium text-sky-800">
                        <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                        Lead Time: {sku.dcLeadTimeWindow ?? '24–48 hrs'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        Incoming Qty: <strong className="text-slate-900">{sku.inTransitQty} units</strong>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        Est. Cost: <strong className="text-slate-900">{formatINR(sku.inTransitQty * sku.unitCost)}</strong>
                      </span>
                      {sku.orderedAt && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-slate-500">Raised {sku.orderedAt}</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 shrink-0">
                    <StatusBadge status={status} inTransit />
                    <button
                      type="button"
                      onClick={() => receiveDCShipment(sku.id)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-emerald-700 rounded-lg hover:bg-emerald-800 transition-colors whitespace-nowrap cursor-pointer"
                    >
                      <PackageCheck className="w-4 h-4" aria-hidden="true" />
                      <span>Receive Shipment</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Reorder Queue */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h2 className="text-base font-semibold text-slate-900">
            Pending Reorder Queue ({actionQueue.length})
          </h2>
          <p className="text-xs text-slate-500">
            SKUs at or below calculated Reorder Point awaiting DC Transfer Order
          </p>
        </div>

        {actionQueue.length === 0 ? (
          <div className="p-10 text-center">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" aria-hidden="true" />
            <p className="text-sm font-semibold text-slate-900">Replenishment Queue Clear</p>
            <p className="text-xs text-slate-500 mt-1">
              Every low-stock SKU is either replenished or already in transit from the Distribution Centre.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                  <th className="py-3 pl-5 pr-3">SKU / Item</th>
                  <th className="py-3 px-3">Status & Class</th>
                  <th className="py-3 px-3 text-right">Avg Sales/d</th>
                  <th className="py-3 px-3 text-right">Lead Time</th>
                  <th className="py-3 px-3 text-right">Safety Stock</th>
                  <th className="py-3 px-3 text-right">ROP Target</th>
                  <th className="py-3 px-3 text-right">Current Stock</th>
                  <th className="py-3 px-3 text-right">Order Qty</th>
                  <th className="py-3 px-3 text-right">Est. Cost</th>
                  <th className="py-3 pl-3 pr-5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-sm">
                {actionQueue.map((sku) => {
                  const rop = calculateROP(sku);
                  const total = getTotalStock(sku);
                  const status = getStockStatus(sku);
                  const defaultOrderQty = getRecommendedOrderQty(sku);
                  const orderQty = customQtys[sku.id] ?? defaultOrderQty;
                  const leadLabel = sku.leadTimeDays <= 2 ? '24 hrs' : '48 hrs';

                  return (
                    <tr key={sku.id} className="hover:bg-slate-50/70">
                      <td className="py-3.5 pl-5 pr-3">
                        <div className="font-semibold text-slate-900">{sku.name}</div>
                        <div className="text-xs text-slate-500 font-mono">
                          {sku.skuCode} · {sku.packSize} · {sku.category}
                        </div>
                      </td>
                      <td className="py-3.5 px-3">
                        <div className="flex flex-col gap-1 items-start">
                          <StatusBadge status={status} />
                          <span className="text-[11px] font-mono text-slate-500">
                            Class {sku.abcTier}{sku.vedClass} · SLA {leadLabel}
                          </span>
                        </div>
                      </td>
                      <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-700">
                        {sku.avgDailySales}
                      </td>
                      <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-700">
                        {sku.leadTimeDays}d
                      </td>
                      <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-700">
                        {sku.safetyStock}
                      </td>
                      <td className="py-3.5 px-3 text-right font-mono tabular-nums font-semibold text-slate-900">
                        {rop}
                      </td>
                      <td className="py-3.5 px-3 text-right font-mono tabular-nums">
                        <span className={total === 0 ? 'font-semibold text-rose-600' : 'font-semibold text-amber-700'}>
                          {total}
                        </span>
                      </td>
                      <td className="py-3.5 px-3 text-right">
                        <input
                          type="number"
                          min={1}
                          max={500}
                          value={orderQty}
                          onChange={(e) => handleQtyChange(sku.id, e.target.value)}
                          aria-label={`Order quantity for ${sku.name}`}
                          className="w-20 px-2 py-1 text-right font-mono text-sm tabular-nums bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:bg-white focus:border-slate-900"
                        />
                      </td>
                      <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-900">
                        {formatINR(orderQty * sku.unitCost)}
                      </td>
                      <td className="py-3.5 pl-3 pr-5 text-right">
                        <button
                          type="button"
                          onClick={() => createDCOrder(sku.id, orderQty)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap cursor-pointer"
                        >
                          <Truck className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Raise DC Order</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};
