import React from 'react';
import { AlertTriangle, CheckCircle2, Info, Truck, X } from 'lucide-react';
import { useInventory } from '../context/InventoryContext';

export const ToastContainer: React.FC = () => {
  const { state, dismissToast } = useInventory();

  if (state.toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 w-[calc(100vw-2rem)] max-w-sm pointer-events-none"
    >
      {state.toasts.map((toast) => {
        const icon =
          toast.tone === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" aria-hidden="true" />
          ) : toast.tone === 'warning' ? (
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" aria-hidden="true" />
          ) : toast.tone === 'danger' ? (
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" aria-hidden="true" />
          ) : toast.title.includes('DC') ? (
            <Truck className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" aria-hidden="true" />
          ) : (
            <Info className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" aria-hidden="true" />
          );

        return (
          <div
            key={toast.id}
            role="status"
            className="pointer-events-auto bg-white border border-slate-200 rounded-lg shadow-md px-3.5 py-3 flex items-start gap-3 transition-all duration-150"
          >
            {icon}
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-slate-900 leading-snug">{toast.title}</p>
              {toast.detail && (
                <p className="text-xs text-slate-500 mt-0.5 leading-snug">{toast.detail}</p>
              )}
            </div>
            <button
              type="button"
              onClick={() => dismissToast(toast.id)}
              aria-label="Dismiss notification"
              className="text-slate-400 hover:text-slate-700 p-0.5 rounded cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
