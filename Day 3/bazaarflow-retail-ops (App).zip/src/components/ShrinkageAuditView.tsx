import React, { useMemo } from 'react';
import { ClipboardMinus, Plus } from 'lucide-react';
import { useInventory } from '../context/InventoryContext';
import { ShrinkageReason } from '../types/inventory';
import { formatINR, getTotalStock } from '../utils/inventoryMath';

export const ShrinkageAuditView: React.FC = () => {
  const { state, openShrinkageModal } = useInventory();

  const stats = useMemo(() => {
    const totalInventoryValue = state.skus.reduce(
      (sum, s) => sum + getTotalStock(s) * s.unitCost,
      0
    );
    const totalShrinkageLoss = state.shrinkageLog.reduce(
      (sum, entry) => sum + entry.totalLossValue,
      0
    );
    const totalUnitsLost = state.shrinkageLog.reduce((sum, entry) => sum + entry.quantity, 0);
    const denominator = totalInventoryValue + totalShrinkageLoss;
    const shrinkageRate = denominator > 0 ? (totalShrinkageLoss / denominator) * 100 : 0;

    const byReason: Record<ShrinkageReason, number> = {
      'Damaged in Handling': 0,
      'Expired / Write-off': 0,
      'Missing / Pilferage': 0,
      'Spillage / Torn Pack': 0,
    };

    for (const entry of state.shrinkageLog) {
      byReason[entry.reason] = (byReason[entry.reason] ?? 0) + entry.totalLossValue;
    }

    return {
      totalInventoryValue,
      totalShrinkageLoss,
      totalUnitsLost,
      shrinkageRate,
      byReason,
    };
  }, [state.skus, state.shrinkageLog]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Inventory Audit & Shrinkage Log
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Track damaged, expired, or missing inventory and monitor live store shrinkage rate
          </p>
        </div>

        <button
          type="button"
          onClick={() => openShrinkageModal()}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors self-start sm:self-auto whitespace-nowrap cursor-pointer"
        >
          <Plus className="w-4 h-4" aria-hidden="true" />
          <span>Log Shrinkage Entry</span>
        </button>
      </div>

      {/* Shrinkage KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Live Shrinkage Rate</p>
          <p
            className={`mt-2 text-2xl font-bold font-mono tabular-nums ${
              stats.shrinkageRate > 1.5 ? 'text-rose-600' : 'text-slate-900'
            }`}
          >
            {stats.shrinkageRate.toFixed(2)}%
          </p>
          <p className="mt-1 text-xs text-slate-500">Target threshold &lt; 1.25%</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Total Write-off Value</p>
          <p className="mt-2 text-2xl font-bold font-mono tabular-nums text-rose-700">
            {formatINR(stats.totalShrinkageLoss)}
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            {stats.totalUnitsLost} total units written off
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Active Stock Valuation</p>
          <p className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900">
            {formatINR(stats.totalInventoryValue)}
          </p>
          <p className="mt-1 text-xs text-slate-500">Net on-hand cost basis</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Primary Loss Driver</p>
          <p className="mt-2 text-base font-semibold text-slate-900 truncate">
            {Object.entries(stats.byReason).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'None'}
          </p>
          <p className="mt-1 text-xs font-mono tabular-nums text-slate-500">
            {formatINR(Object.entries(stats.byReason).sort((a, b) => b[1] - a[1])[0]?.[1] ?? 0)} loss
          </p>
        </div>
      </div>

      {/* Audit Ledger Table */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h2 className="text-base font-semibold text-slate-900">
            Shrinkage Audit Ledger ({state.shrinkageLog.length})
          </h2>
        </div>

        {state.shrinkageLog.length === 0 ? (
          <div className="p-10 text-center">
            <ClipboardMinus className="w-8 h-8 text-slate-300 mx-auto mb-2" aria-hidden="true" />
            <p className="text-sm font-semibold text-slate-900">No shrinkage events recorded</p>
            <p className="text-xs text-slate-500 mt-1">
              Log damaged, expired, or missing floor items to track store shrinkage rate.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                  <th className="py-3 pl-5 pr-3">Timestamp</th>
                  <th className="py-3 px-3">SKU / Product</th>
                  <th className="py-3 px-3">Location</th>
                  <th className="py-3 px-3">Reason</th>
                  <th className="py-3 px-3 text-right">Qty</th>
                  <th className="py-3 px-3 text-right">Loss Value</th>
                  <th className="py-3 pl-3 pr-5">Audited By & Note</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-sm">
                {state.shrinkageLog.map((entry) => (
                  <tr key={entry.id} className="hover:bg-slate-50/70">
                    <td className="py-3.5 pl-5 pr-3 text-xs font-mono text-slate-600 whitespace-nowrap">
                      {entry.timestamp}
                    </td>
                    <td className="py-3.5 px-3">
                      <div className="font-semibold text-slate-900">{entry.productName}</div>
                      <div className="text-xs font-mono text-slate-500">
                        {entry.skuCode} · {entry.category}
                      </div>
                    </td>
                    <td className="py-3.5 px-3 text-xs font-medium text-slate-700">
                      {entry.location}
                    </td>
                    <td className="py-3.5 px-3">
                      <span className="inline-flex px-2 py-0.5 text-xs font-medium rounded-md bg-rose-50 text-rose-700 border border-rose-200 whitespace-nowrap">
                        {entry.reason}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono tabular-nums font-semibold text-slate-900">
                      -{entry.quantity}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono tabular-nums font-semibold text-rose-700">
                      {formatINR(entry.totalLossValue)}
                    </td>
                    <td className="py-3.5 pl-3 pr-5">
                      <div className="text-xs font-medium text-slate-800">{entry.loggedBy}</div>
                      <div className="text-xs text-slate-500">{entry.note}</div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};
