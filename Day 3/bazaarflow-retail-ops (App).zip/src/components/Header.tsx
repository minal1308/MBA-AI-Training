import React from 'react';
import { MonitorCheck, Store } from 'lucide-react';
import { useInventory } from '../context/InventoryContext';
import { StaffTab } from '../types/inventory';

const NAV_ITEMS: Array<{ id: StaffTab; label: string }> = [
  { id: 'overview', label: 'Overview' },
  { id: 'tracker', label: 'Stock Tracker' },
  { id: 'replenishment', label: 'Replenishment' },
  { id: 'audit', label: 'Shrinkage Log' },
];

export const Header: React.FC = () => {
  const { state, setMode, setTab } = useInventory();
  const isStaff = state.mode === 'staff';

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 sm:gap-8">
        {/* Zone 1: Single-line brand wordmark */}
        <button
          type="button"
          onClick={() => {
            setMode('staff');
            setTab('overview');
          }}
          className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-slate-900 cursor-pointer"
        >
          BazaarFlow
        </button>

        {/* Zone 2: Concise single-line navigation links */}
        {isStaff ? (
          <nav
            aria-label="Store operations sections"
            className="hidden md:flex items-center gap-6 text-sm font-medium"
          >
            {NAV_ITEMS.map((item) => {
              const active = state.activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTab(item.id)}
                  className={`py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer border-b-2 ${
                    active
                      ? 'text-slate-900 border-slate-900 font-semibold'
                      : 'text-slate-500 border-transparent hover:text-slate-900'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>
        ) : (
          <div className="hidden md:flex items-center text-sm font-medium text-slate-500 whitespace-nowrap shrink-0">
            In-Store Product Availability & Aisle Finder
          </div>
        )}

        {/* Zone 3: Staff Operations / Customer Kiosk Mode Toggle */}
        <div
          role="group"
          aria-label="Application mode switch"
          className="flex items-center p-1 bg-slate-100 rounded-lg border border-slate-200 shrink-0"
        >
          <button
            type="button"
            onClick={() => setMode('staff')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              isStaff
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Store className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Staff Ops</span>
          </button>
          <button
            type="button"
            onClick={() => setMode('kiosk')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              !isStaff
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <MonitorCheck className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Customer Kiosk</span>
          </button>
        </div>
      </div>

      {/* Mobile Staff Tab Switcher (compact single row below header only on < md) */}
      {isStaff && (
        <nav
          aria-label="Mobile sections"
          className="flex md:hidden items-center gap-1 px-4 pb-2 overflow-x-auto border-t border-slate-100 pt-1.5"
        >
          {NAV_ITEMS.map((item) => {
            const active = state.activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  active
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>
      )}
    </header>
  );
};
