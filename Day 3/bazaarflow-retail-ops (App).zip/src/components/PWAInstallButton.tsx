import React, { useState } from 'react';
import { Check, Copy, Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [copied, setCopied] = useState(false);

  if (isInstalled) {
    return null;
  }

  const currentUrl = typeof window !== 'undefined' ? window.location.origin : '';

  const handleAction = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (!accepted) {
        setShowGuide(true);
      }
      return;
    }
    setShowGuide(true);
  };

  const handleCopyUrl = async () => {
    if (!currentUrl) return;
    try {
      await navigator.clipboard.writeText(currentUrl);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard unavailable
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={handleAction}
        className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
      >
        {isInstallable ? (
          <Download className="w-4 h-4 shrink-0" aria-hidden="true" />
        ) : (
          <Smartphone className="w-4 h-4 shrink-0" aria-hidden="true" />
        )}
        <span>{isInstallable ? 'Install Android App' : 'Get Mobile App'}</span>
      </button>

      {showGuide && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="pwa-install-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-[1px] p-4"
        >
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Smartphone className="w-5 h-5 text-slate-900" aria-hidden="true" />
                <h3 id="pwa-install-title" className="text-base font-bold text-slate-900">
                  Install BazaarFlow on {isIOS ? 'iPhone / iPad' : 'Android'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                aria-label="Close install guide"
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-sm text-slate-600">
              {isIOS ? (
                <ol className="list-decimal list-inside space-y-2 text-slate-700">
                  <li>
                    Open this app URL in <strong>Safari</strong> on your iPhone or iPad.
                  </li>
                  <li>
                    Tap the <strong>Share</strong> icon in the bottom Safari bar.
                  </li>
                  <li>
                    Scroll down and select <strong>Add to Home Screen</strong>.
                  </li>
                </ol>
              ) : (
                <div className="space-y-3">
                  <p className="text-slate-700">
                    BazaarFlow is configured as an installable Android Progressive Web App (offline-ready, standalone full-screen mode):
                  </p>
                  <ol className="list-decimal list-inside space-y-2 text-slate-700">
                    <li>
                      Open the app URL below in <strong>Google Chrome</strong> on your Android phone (outside preview frames).
                    </li>
                    <li>
                      Tap the <strong>Install Android App</strong> button or Chrome&apos;s{' '}
                      <strong>⋮ menu → Install app</strong>.
                    </li>
                    <li>
                      The app installs directly to your Android home screen and app drawer with offline floor stock caching.
                    </li>
                  </ol>
                </div>
              )}

              {currentUrl && (
                <div className="pt-2">
                  <label className="block text-xs font-semibold text-slate-500 mb-1">
                    App Launch URL
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={currentUrl}
                      className="flex-1 px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg text-slate-700"
                    />
                    <button
                      type="button"
                      onClick={handleCopyUrl}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer shrink-0"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" aria-hidden="true" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600 space-y-1">
                <p className="font-semibold text-slate-800">Need a distributable .APK / Play Store .AAB?</p>
                <p>
                  Package this live PWA into a signed Android APK using Google&apos;s Bubblewrap CLI:{' '}
                  <code className="font-mono text-slate-800">
                    npx @bubblewrap/cli init --manifest {currentUrl || 'https://your-app-url'}/manifest.webmanifest
                  </code>
                </p>
              </div>
            </div>

            <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="px-4 py-2 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
