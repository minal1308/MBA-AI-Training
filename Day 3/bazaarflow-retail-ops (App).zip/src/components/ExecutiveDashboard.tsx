import React, { useMemo } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ArrowRight, ClipboardMinus, PackagePlus, RotateCcw, Truck } from 'lucide-react';
import { useInventory } from '../context/InventoryContext';
import { ABCTier, Category, VEDClass } from '../types/inventory';
import {
  calculateROP,
  formatINR,
  formatINRLakhs,
  getDaysOfCover,
  getRecommendedOrderQty,
  getStockStatus,
  getTotalStock,
  isCriticalStockout,
  isPendingReplenishment,
} from '../utils/inventoryMath';
import { PWAInstallButton } from './PWAInstallButton';
import { StatusBadge } from './StatusBadge';

const CATEGORIES: Category[] = ['Staples', 'Dairy', 'FMCG', 'Home Care', 'General Merchandise'];
const ABC_TIERS: ABCTier[] = ['A', 'B', 'C'];
const VED_CLASSES: VEDClass[] = ['V', 'E', 'D'];

export const ExecutiveDashboard: React.FC = () => {
  const {
    state,
    navigateToTrackerWithFilter,
    setTab,
    restockShelf,
    createDCOrder,
    receiveDCShipment,
    openShrinkageModal,
    resetDemoData,
  } = useInventory();

  const metrics = useMemo(() => {
    const totalSkus = state.skus.length;
    const onShelfCount = state.skus.filter((s) => s.shelfStock > 0).length;
    const osaRate = totalSkus > 0 ? (onShelfCount / totalSkus) * 100 : 0;

    const criticalStockouts = state.skus.filter(isCriticalStockout).length;
    const pendingReplenishments = state.skus.filter(isPendingReplenishment);
    const inTransitCount = state.skus.filter((s) => s.inTransit).length;

    const totalCostValue = state.skus.reduce(
      (sum, s) => sum + getTotalStock(s) * s.unitCost,
      0
    );
    const totalMrpValue = state.skus.reduce(
      (sum, s) => sum + getTotalStock(s) * s.mrp,
      0
    );
    const totalShrinkageLoss = state.shrinkageLog.reduce((sum, e) => sum + e.totalLossValue, 0);
    const shrinkageRate =
      totalCostValue + totalShrinkageLoss > 0
        ? (totalShrinkageLoss / (totalCostValue + totalShrinkageLoss)) * 100
        : 0;

    return {
      totalSkus,
      onShelfCount,
      osaRate,
      criticalStockouts,
      pendingCount: pendingReplenishments.length,
      inTransitCount,
      totalCostValue,
      totalMrpValue,
      shrinkageRate,
    };
  }, [state.skus, state.shrinkageLog]);

  const categoryChartData = useMemo(() => {
    return CATEGORIES.map((cat) => {
      const items = state.skus.filter((s) => s.category === cat);
      let optimal = 0;
      let lowStock = 0;
      let outOfStock = 0;

      for (const item of items) {
        const st = getStockStatus(item);
        if (st === 'Optimal') optimal += 1;
        else if (st === 'Out of Stock') outOfStock += 1;
        else lowStock += 1;
      }

      return {
        category: cat === 'General Merchandise' ? 'Gen. Merch.' : cat,
        fullCategory: cat,
        Optimal: optimal,
        'Low / Critical': lowStock,
        'Out of Stock': outOfStock,
      };
    });
  }, [state.skus]);

  const abcVedMatrix = useMemo(() => {
    const cells: Record<
      string,
      { count: number; alertCount: number; costValue: number }
    > = {};
    for (const abc of ABC_TIERS) {
      for (const ved of VED_CLASSES) {
        cells[`${abc}${ved}`] = { count: 0, alertCount: 0, costValue: 0 };
      }
    }
    for (const sku of state.skus) {
      const key = `${sku.abcTier}${sku.vedClass}`;
      const st = getStockStatus(sku);
      cells[key].count += 1;
      cells[key].costValue += getTotalStock(sku) * sku.unitCost;
      if (st !== 'Optimal') {
        cells[key].alertCount += 1;
      }
    }
    return cells;
  }, [state.skus]);

  const urgentSkus = useMemo(() => {
    return state.skus
      .filter((s) => {
        const st = getStockStatus(s);
        return st === 'Out of Stock' || st === 'Critical' || (s.shelfStock === 0 && s.backroomStock > 0);
      })
      .sort((a, b) => {
        const order = { 'Out of Stock': 0, Critical: 1, 'Low Stock': 2, Optimal: 3 };
        return order[getStockStatus(a)] - order[getStockStatus(b)];
      });
  }, [state.skus]);

  return (
    <div className="space-y-6">
      {/* Workspace Header & Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Store Inventory Overview
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Indiranagar Supermart (BLR-04) · Real-time shelf, backroom & DC replenishment telemetry
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <PWAInstallButton />
          <button
            type="button"
            onClick={() => openShrinkageModal()}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <ClipboardMinus className="w-4 h-4 text-slate-500" aria-hidden="true" />
            <span>Log Shrinkage</span>
          </button>
          <button
            type="button"
            onClick={resetDemoData}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-slate-400" aria-hidden="true" />
            <span>Reset Baseline</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('replenishment')}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>Replenishment Queue</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* 5 KPI Summary Cards */}
      <section aria-label="Key store inventory indicators" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Total Active SKUs</p>
          <p className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900">
            {metrics.totalSkus}
          </p>
          <p className="mt-1 text-xs text-slate-500">5 store departments</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">On-Shelf Availability</p>
          <p className="mt-2 text-2xl font-bold font-mono tabular-nums text-emerald-700">
            {metrics.osaRate.toFixed(1)}%
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            {metrics.onShelfCount} of {metrics.totalSkus} SKUs on floor
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigateToTrackerWithFilter({ status: 'Out of Stock' })}
          className="text-left bg-white border border-slate-200 rounded-xl p-4 hover:border-rose-300 transition-colors cursor-pointer"
        >
          <p className="text-xs font-medium text-slate-500">Critical Stockouts</p>
          <p
            className={`mt-2 text-2xl font-bold font-mono tabular-nums ${
              metrics.criticalStockouts > 0 ? 'text-rose-600' : 'text-emerald-700'
            }`}
          >
            {metrics.criticalStockouts}
          </p>
          <p className="mt-1 text-xs text-slate-500">Vital / Cat-A at 0 stock</p>
        </button>

        <button
          type="button"
          onClick={() => setTab('replenishment')}
          className="text-left bg-white border border-slate-200 rounded-xl p-4 hover:border-amber-300 transition-colors cursor-pointer"
        >
          <p className="text-xs font-medium text-slate-500">Pending Replenishments</p>
          <p className="mt-2 text-2xl font-bold font-mono tabular-nums text-amber-700">
            {metrics.pendingCount}
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            Below ROP · {metrics.inTransitCount} in transit
          </p>
        </button>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Total Inventory Value</p>
          <p className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900">
            {formatINRLakhs(metrics.totalCostValue)}
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            MRP {formatINRLakhs(metrics.totalMrpValue)} · Shrink {metrics.shrinkageRate.toFixed(2)}%
          </p>
        </div>
      </section>

      {/* Visual Analytics: Category Health Chart + ABC-VED Priority Matrix */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Category Stock Health Bar Chart */}
        <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 flex flex-col">
          <div className="flex items-start justify-between gap-4 mb-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">Stock Health by Category</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                SKU distribution across Optimal, Low/Critical, and Out-of-Stock states
              </p>
            </div>
            <button
              type="button"
              onClick={() => navigateToTrackerWithFilter({})}
              className="text-xs font-medium text-slate-600 hover:text-slate-900 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Inspect Grid →
            </button>
          </div>
          <div className="h-72 w-full mt-auto">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={categoryChartData}
                margin={{ top: 8, right: 12, left: -16, bottom: 4 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis
                  dataKey="category"
                  tick={{ fill: '#475569', fontSize: 12 }}
                  axisLine={{ stroke: '#cbd5e1' }}
                  tickLine={false}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fill: '#64748b', fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '8px',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '8px' }} />
                <Bar dataKey="Optimal" stackId="a" fill="#10b981" radius={[0, 0, 0, 0]} />
                <Bar dataKey="Low / Critical" stackId="a" fill="#f59e0b" radius={[0, 0, 0, 0]} />
                <Bar dataKey="Out of Stock" stackId="a" fill="#e11d48" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Interactive ABC-VED Priority Matrix */}
        <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 flex flex-col">
          <div className="flex items-start justify-between gap-4 mb-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">ABC-VED Priority Matrix</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Consumption Value (A/B/C) vs Criticality (Vital/Essential/Desirable) — click cell to filter
              </p>
            </div>
          </div>

          <div className="overflow-x-auto flex-1 flex flex-col justify-center">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr>
                  <th className="py-2 pr-3 text-xs font-medium text-slate-500 w-24">Value \ Crit.</th>
                  <th className="py-2 px-2 text-xs font-semibold text-slate-700 text-center">
                    V · Vital
                  </th>
                  <th className="py-2 px-2 text-xs font-semibold text-slate-700 text-center">
                    E · Essential
                  </th>
                  <th className="py-2 px-2 text-xs font-semibold text-slate-700 text-center">
                    D · Desirable
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {ABC_TIERS.map((abc) => (
                  <tr key={abc}>
                    <td className="py-2 pr-3 align-middle">
                      <div className="text-xs font-semibold text-slate-900">Class {abc}</div>
                      <div className="text-[11px] text-slate-500">
                        {abc === 'A' ? 'High Value' : abc === 'B' ? 'Mid Value' : 'Low Value'}
                      </div>
                    </td>
                    {VED_CLASSES.map((ved) => {
                      const cell = abcVedMatrix[`${abc}${ved}`];
                      const isHighPriority =
                        (abc === 'A' && (ved === 'V' || ved === 'E')) ||
                        (abc === 'B' && ved === 'V');
                      return (
                        <td key={`${abc}${ved}`} className="p-1.5">
                          <button
                            type="button"
                            onClick={() => navigateToTrackerWithFilter({ abc, ved })}
                            className={`w-full text-left p-2.5 rounded-lg border transition-colors cursor-pointer ${
                              cell.alertCount > 0 && isHighPriority
                                ? 'bg-rose-50/70 border-rose-200 hover:bg-rose-50'
                                : isHighPriority
                                  ? 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                                  : 'bg-white border-slate-200 hover:bg-slate-50'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-xs font-mono font-semibold text-slate-900">
                                {abc}{ved}
                              </span>
                              <span className="text-xs font-mono tabular-nums text-slate-600">
                                {cell.count} SKUs
                              </span>
                            </div>
                            <div className="mt-1 flex items-center justify-between text-[11px] tabular-nums">
                              <span className="text-slate-500">{formatINRLakhs(cell.costValue)}</span>
                              {cell.alertCount > 0 ? (
                                <span className="font-semibold text-rose-700">
                                  {cell.alertCount} alert
                                </span>
                              ) : (
                                <span className="text-emerald-700">Healthy</span>
                              )}
                            </div>
                          </button>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Immediate Floor & DC Action Alerts */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Immediate Floor & Replenishment Alerts
            </h2>
            <p className="text-xs text-slate-500">
              Vital stockouts, empty shelves with backroom inventory, and SKUs below 50% Reorder Point
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigateToTrackerWithFilter({ status: 'Low Stock' })}
            className="text-xs font-medium text-slate-700 hover:text-slate-900 self-start sm:self-auto whitespace-nowrap cursor-pointer"
          >
            View all floor stock →
          </button>
        </div>

        {urgentSkus.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            All vital staples and floor shelves are currently above critical thresholds.
          </div>
        ) : (
          <div className="divide-y divide-slate-200">
            {urgentSkus.map((sku) => {
              const status = getStockStatus(sku);
              const total = getTotalStock(sku);
              const rop = calculateROP(sku);
              const cover = getDaysOfCover(sku);
              const recQty = getRecommendedOrderQty(sku);

              return (
                <div
                  key={sku.id}
                  className="px-5 py-3.5 flex flex-col lg:flex-row lg:items-center justify-between gap-3 hover:bg-slate-50/70 transition-colors"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-mono font-semibold text-slate-500">
                        {sku.skuCode}
                      </span>
                      <span className="text-sm font-semibold text-slate-900">{sku.name}</span>
                      <span className="text-xs text-slate-500">
                        {sku.packSize} · {sku.aisle} - {sku.bay} · Class {sku.abcTier}{sku.vedClass}
                      </span>
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-slate-600 tabular-nums">
                      <span>
                        Shelf: <strong className="text-slate-900">{sku.shelfStock}</strong>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        Backroom: <strong className="text-slate-900">{sku.backroomStock}</strong>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        Total: <strong className="text-slate-900">{total}</strong> / ROP {rop}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>Cover: {cover}d</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <StatusBadge status={status} inTransit={sku.inTransit} />

                    {sku.backroomStock > 0 && sku.shelfStock < sku.shelfCapacity && (
                      <button
                        type="button"
                        onClick={() => restockShelf(sku.id)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-800 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <PackagePlus className="w-3.5 h-3.5 text-emerald-600" aria-hidden="true" />
                        <span>+Restock Shelf</span>
                      </button>
                    )}

                    {sku.inTransit ? (
                      <button
                        type="button"
                        onClick={() => receiveDCShipment(sku.id)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-sky-800 bg-sky-50 border border-sky-200 rounded-lg hover:bg-sky-100 transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <Truck className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Receive +{sku.inTransitQty}</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => createDCOrder(sku.id)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <Truck className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Order DC (+{recQty})</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
