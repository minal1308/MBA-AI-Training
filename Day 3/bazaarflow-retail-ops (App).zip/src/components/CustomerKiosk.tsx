import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  MapPin,
  Search,
  X,
  XCircle,
} from 'lucide-react';
import { useInventory } from '../context/InventoryContext';
import { Category, SKU } from '../types/inventory';
import {
  findKioskAlternatives,
  formatINR,
  getKioskAvailability,
} from '../utils/inventoryMath';

const CATEGORIES: Array<Category | 'All'> = [
  'All',
  'Staples',
  'Dairy',
  'FMCG',
  'Home Care',
  'General Merchandise',
];

export const CustomerKiosk: React.FC = () => {
  const { state } = useInventory();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<Category | 'All'>('All');
  const [onlyAvailable, setOnlyAvailable] = useState(false);

  const results = useMemo(() => {
    const q = search.trim().toLowerCase();
    return state.skus.filter((sku) => {
      if (category !== 'All' && sku.category !== category) return false;
      if (onlyAvailable && sku.shelfStock === 0) return false;
      if (q) {
        return (
          sku.name.toLowerCase().includes(q) ||
          sku.brand.toLowerCase().includes(q) ||
          sku.barcode.toLowerCase().includes(q) ||
          sku.category.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [state.skus, search, category, onlyAvailable]);

  const handleSelectAlternative = (alt: SKU) => {
    setCategory('All');
    setOnlyAvailable(false);
    setSearch(alt.name);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Kiosk Hero Search */}
      <section className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8">
        <div className="max-w-2xl">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
            Find Products & Shelf Locations
          </h1>
          <p className="text-sm sm:text-base text-slate-500 mt-1.5">
            Check live shelf availability, MRP, and exact aisle numbers across Indiranagar Supermart.
          </p>
        </div>

        <div className="mt-5 relative">
          <Search
            className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by product name, brand (e.g. Amul, Tata, Atta), or barcode..."
            aria-label="Search store products"
            className="w-full pl-12 pr-10 py-3.5 text-base bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-slate-900"
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch('')}
              aria-label="Clear product search"
              className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategory(cat)}
                className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  category === cat
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setOnlyAvailable((prev) => !prev)}
            className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg border transition-colors whitespace-nowrap cursor-pointer ${
              onlyAvailable
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {onlyAvailable ? 'Showing In-Stock Only' : 'Show In-Stock Only'}
          </button>
        </div>
      </section>

      {/* Results Count */}
      <div className="flex items-center justify-between text-xs sm:text-sm text-slate-500 px-1">
        <span className="tabular-nums">
          {results.length} {results.length === 1 ? 'item' : 'items'} found
        </span>
        {(search || category !== 'All' || onlyAvailable) && (
          <button
            type="button"
            onClick={() => {
              setSearch('');
              setCategory('All');
              setOnlyAvailable(false);
            }}
            className="font-medium text-slate-700 hover:text-slate-900 cursor-pointer"
          >
            Reset search
          </button>
        )}
      </div>

      {/* Product Grid */}
      {results.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center">
          <p className="text-base font-semibold text-slate-900">No matching products found</p>
          <p className="text-sm text-slate-500 mt-1">
            Try searching a broader term like &ldquo;Milk&rdquo;, &ldquo;Dal&rdquo;, or &ldquo;Detergent&rdquo;.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {results.map((sku) => {
            const avail = getKioskAvailability(sku);
            const alternatives =
              avail.label === 'Out of Stock' ? findKioskAlternatives(sku, state.skus) : [];

            const badgeStyles =
              avail.tone === 'emerald'
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                : avail.tone === 'amber'
                  ? 'bg-amber-50 text-amber-800 border-amber-200'
                  : 'bg-rose-50 text-rose-800 border-rose-200';

            const StatusIcon =
              avail.tone === 'emerald'
                ? CheckCircle2
                : avail.tone === 'amber'
                  ? AlertTriangle
                  : XCircle;

            return (
              <article
                key={sku.id}
                className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between gap-4"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-xs font-medium text-slate-500">
                        {sku.brand} · {sku.category}
                      </p>
                      <h2 className="text-base font-semibold text-slate-900 mt-0.5 leading-snug">
                        {sku.name}
                      </h2>
                      <p className="text-xs text-slate-500 mt-0.5">Pack Size: {sku.packSize}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-[11px] text-slate-500">MRP</p>
                      <p className="text-xl font-bold font-mono tabular-nums text-slate-900">
                        {formatINR(sku.mrp)}
                      </p>
                    </div>
                  </div>

                  {/* Live Availability & Location */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100">
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-md border ${badgeStyles}`}
                    >
                      <StatusIcon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>{avail.label}</span>
                    </span>

                    <div className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-800">
                      <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" aria-hidden="true" />
                      <span>
                        {sku.aisle} · {sku.bay} · {sku.shelfLevel}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-500">{avail.note}</p>
                </div>

                {/* Alternative In-Stock Suggestions for Out-of-Stock Items */}
                {alternatives.length > 0 && (
                  <div className="pt-3 border-t border-slate-200 space-y-2">
                    <p className="text-xs font-semibold text-slate-700">
                      Available Alternatives in {sku.category}:
                    </p>
                    <div className="space-y-1.5">
                      {alternatives.map((alt) => (
                        <button
                          key={alt.id}
                          type="button"
                          onClick={() => handleSelectAlternative(alt)}
                          className="w-full text-left px-3 py-2 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 flex items-center justify-between gap-3 transition-colors cursor-pointer"
                        >
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-slate-900 truncate">
                              {alt.name} ({alt.packSize})
                            </p>
                            <p className="text-[11px] text-slate-500">
                              {alt.aisle} · {alt.bay} · {alt.shelfStock} on shelf
                            </p>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className="text-xs font-mono font-semibold text-slate-900 tabular-nums">
                              {formatINR(alt.mrp)}
                            </span>
                            <ArrowRight className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
