import React, { useMemo } from 'react';
import {
  ClipboardMinus,
  Minus,
  PackageCheck,
  PackagePlus,
  RotateCcw,
  Search,
  Truck,
  X,
} from 'lucide-react';
import { useInventory } from '../context/InventoryContext';
import { ABCTier, Category, StockStatus, VEDClass } from '../types/inventory';
import {
  calculateROP,
  formatINR,
  getDaysOfCover,
  getRecommendedOrderQty,
  getStockStatus,
  getTotalStock,
} from '../utils/inventoryMath';
import { StatusBadge } from './StatusBadge';

const CATEGORIES: Array<Category | 'All'> = [
  'All',
  'Staples',
  'Dairy',
  'FMCG',
  'Home Care',
  'General Merchandise',
];

const STATUS_OPTIONS: Array<StockStatus | 'All' | 'In Transit'> = [
  'All',
  'Optimal',
  'Low Stock',
  'Critical',
  'Out of Stock',
  'In Transit',
];

const ABC_OPTIONS: Array<ABCTier | 'All'> = ['All', 'A', 'B', 'C'];
const VED_OPTIONS: Array<VEDClass | 'All'> = ['All', 'V', 'E', 'D'];

export const StockTracker: React.FC = () => {
  const {
    state,
    setFilters,
    resetFilters,
    recordSale,
    restockShelf,
    createDCOrder,
    receiveDCShipment,
    openShrinkageModal,
  } = useInventory();

  const { filters } = state;

  const filteredSkus = useMemo(() => {
    const q = filters.search.trim().toLowerCase();
    return state.skus.filter((sku) => {
      if (q) {
        const matches =
          sku.skuCode.toLowerCase().includes(q) ||
          sku.name.toLowerCase().includes(q) ||
          sku.brand.toLowerCase().includes(q) ||
          sku.barcode.toLowerCase().includes(q);
        if (!matches) return false;
      }

      if (filters.category !== 'All' && sku.category !== filters.category) return false;
      if (filters.abc !== 'All' && sku.abcTier !== filters.abc) return false;
      if (filters.ved !== 'All' && sku.vedClass !== filters.ved) return false;

      if (filters.status !== 'All') {
        if (filters.status === 'In Transit') {
          if (!sku.inTransit) return false;
        } else if (getStockStatus(sku) !== filters.status) {
          return false;
        }
      }

      return true;
    });
  }, [state.skus, filters]);

  const hasActiveFilters =
    filters.search !== '' ||
    filters.category !== 'All' ||
    filters.status !== 'All' ||
    filters.abc !== 'All' ||
    filters.ved !== 'All';

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Floor & Backroom Stock Tracker
          </h1>
          <p className="text-sm text-slate-500 mt-0.5 tabular-nums">
            Showing {filteredSkus.length} of {state.skus.length} active SKUs · Instant floor sales, shelf pulls & DC receipts
          </p>
        </div>
        <button
          type="button"
          onClick={() => openShrinkageModal()}
          className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors self-start sm:self-auto whitespace-nowrap shrink-0 cursor-pointer"
        >
          <ClipboardMinus className="w-4 h-4 text-slate-500" aria-hidden="true" />
          <span>Log Shrinkage</span>
        </button>
      </div>

      {/* Search & Multi-Faceted Filters */}
      <section aria-label="Inventory filters" className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Instant Search */}
          <div className="md:col-span-5 relative">
            <Search
              className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="text"
              value={filters.search}
              onChange={(e) => setFilters({ search: e.target.value })}
              placeholder="Search SKU code, product name, or 890 barcode..."
              aria-label="Search SKU, product name, or barcode"
              className="w-full pl-9 pr-8 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-slate-900"
            />
            {filters.search && (
              <button
                type="button"
                onClick={() => setFilters({ search: '' })}
                aria-label="Clear search"
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Category Select */}
          <div className="md:col-span-3">
            <select
              value={filters.category}
              onChange={(e) => setFilters({ category: e.target.value as Category | 'All' })}
              aria-label="Filter by category"
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:bg-white focus:border-slate-900"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat === 'All' ? 'All Categories' : cat}
                </option>
              ))}
            </select>
          </div>

          {/* Status Select */}
          <div className="md:col-span-2">
            <select
              value={filters.status}
              onChange={(e) =>
                setFilters({ status: e.target.value as StockStatus | 'All' | 'In Transit' })
              }
              aria-label="Filter by stock status"
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:bg-white focus:border-slate-900"
            >
              {STATUS_OPTIONS.map((st) => (
                <option key={st} value={st}>
                  {st === 'All' ? 'All Statuses' : st}
                </option>
              ))}
            </select>
          </div>

          {/* Reset Filters */}
          <div className="md:col-span-2 flex items-center justify-end">
            <button
              type="button"
              onClick={resetFilters}
              disabled={!hasActiveFilters}
              className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Clear Filters</span>
            </button>
          </div>
        </div>

        {/* ABC & VED Segmented Filters */}
        <div className="flex flex-wrap items-center gap-4 pt-2 border-t border-slate-100">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-slate-500">ABC Tier:</span>
            <div className="inline-flex items-center p-0.5 bg-slate-100 rounded-lg">
              {ABC_OPTIONS.map((tier) => (
                <button
                  key={tier}
                  type="button"
                  onClick={() => setFilters({ abc: tier })}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                    filters.abc === tier
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tier === 'All' ? 'All' : `Tier ${tier}`}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-slate-500">VED Criticality:</span>
            <div className="inline-flex items-center p-0.5 bg-slate-100 rounded-lg">
              {VED_OPTIONS.map((ved) => (
                <button
                  key={ved}
                  type="button"
                  onClick={() => setFilters({ ved })}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                    filters.ved === ved
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {ved === 'All'
                    ? 'All'
                    : ved === 'V'
                      ? 'Vital (V)'
                      : ved === 'E'
                        ? 'Essential (E)'
                        : 'Desirable (D)'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Empty State */}
      {filteredSkus.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center">
          <p className="text-base font-semibold text-slate-900">No SKUs match these filters</p>
          <p className="text-sm text-slate-500 mt-1">
            Try clearing your search term or resetting ABC-VED and status filters.
          </p>
          <button
            type="button"
            onClick={resetFilters}
            className="mt-4 px-4 py-2 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Reset All Filters
          </button>
        </div>
      ) : (
        <>
          {/* Desktop High-Density Table */}
          <div className="hidden lg:block bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                    <th className="py-3 pl-4 pr-3">SKU / Product</th>
                    <th className="py-3 px-3">Location</th>
                    <th className="py-3 px-3">Class</th>
                    <th className="py-3 px-3 text-right">MRP</th>
                    <th className="py-3 px-3 text-right">Shelf</th>
                    <th className="py-3 px-3 text-right">Backroom</th>
                    <th className="py-3 px-3 text-right">Total / ROP</th>
                    <th className="py-3 px-3 text-right">Cover</th>
                    <th className="py-3 px-3">Status</th>
                    <th className="py-3 pl-3 pr-4 text-right">Floor & DC Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-sm">
                  {filteredSkus.map((sku) => {
                    const total = getTotalStock(sku);
                    const rop = calculateROP(sku);
                    const status = getStockStatus(sku);
                    const cover = getDaysOfCover(sku);
                    const recQty = getRecommendedOrderQty(sku);

                    return (
                      <tr key={sku.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 pl-4 pr-3 max-w-[270px]">
                          <div className="font-semibold text-slate-900 truncate">{sku.name}</div>
                          <div className="text-xs text-slate-500 font-mono tabular-nums mt-0.5 truncate">
                            {sku.skuCode} · {sku.packSize} · {sku.barcode}
                          </div>
                        </td>
                        <td className="py-3 px-3 whitespace-nowrap">
                          <div className="text-xs font-medium text-slate-800">
                            {sku.aisle} - {sku.bay}
                          </div>
                          <div className="text-[11px] text-slate-500">{sku.category}</div>
                        </td>
                        <td className="py-3 px-3 whitespace-nowrap">
                          <span className="font-mono text-xs font-semibold text-slate-800">
                            {sku.abcTier}{sku.vedClass}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-900 whitespace-nowrap">
                          {formatINR(sku.mrp)}
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                          <span
                            className={`font-semibold ${
                              sku.shelfStock === 0 ? 'text-rose-600' : 'text-slate-900'
                            }`}
                          >
                            {sku.shelfStock}
                          </span>
                          <span className="text-xs text-slate-400">/{sku.shelfCapacity}</span>
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700 whitespace-nowrap">
                          {sku.backroomStock}
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                          <span className="font-semibold text-slate-900">{total}</span>
                          <span className="text-xs text-slate-400"> / {rop}</span>
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                          <span
                            className={
                              cover <= 1.5
                                ? 'font-semibold text-rose-600'
                                : cover <= 3
                                  ? 'font-semibold text-amber-700'
                                  : 'text-slate-700'
                            }
                          >
                            {cover}d
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <StatusBadge status={status} inTransit={sku.inTransit} />
                        </td>
                        <td className="py-3 pl-3 pr-4">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => recordSale(sku.id)}
                              disabled={sku.shelfStock === 0}
                              title="Record 1 unit sold from shelf"
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer"
                            >
                              <Minus className="w-3 h-3" aria-hidden="true" />
                              <span>1 Sale</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => restockShelf(sku.id)}
                              disabled={sku.backroomStock === 0}
                              title="Pull stock from backroom to shelf"
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-md hover:bg-emerald-100 disabled:opacity-40 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer"
                            >
                              <PackagePlus className="w-3 h-3" aria-hidden="true" />
                              <span>Restock Shelf</span>
                            </button>

                            {sku.inTransit ? (
                              <button
                                type="button"
                                onClick={() => receiveDCShipment(sku.id)}
                                title="Receive incoming DC shipment"
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-sky-800 bg-sky-50 border border-sky-200 rounded-md hover:bg-sky-100 whitespace-nowrap cursor-pointer"
                              >
                                <PackageCheck className="w-3 h-3" aria-hidden="true" />
                                <span>Receive DC (+{sku.inTransitQty})</span>
                              </button>
                            ) : status !== 'Optimal' ? (
                              <button
                                type="button"
                                onClick={() => createDCOrder(sku.id)}
                                title="Raise DC Transfer Order (24-48h)"
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-md hover:bg-slate-800 whitespace-nowrap cursor-pointer"
                              >
                                <Truck className="w-3 h-3" aria-hidden="true" />
                                <span>Order DC (+{recQty})</span>
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => receiveDCShipment(sku.id)}
                                title="Receive scheduled DC shipment directly"
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-100 whitespace-nowrap cursor-pointer"
                              >
                                <Truck className="w-3 h-3" aria-hidden="true" />
                                <span>+Receive DC</span>
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => openShrinkageModal(sku.id)}
                              title="Log damaged, expired, or missing units"
                              aria-label={`Log shrinkage for ${sku.name}`}
                              className="p-1.5 text-slate-400 hover:text-rose-600 rounded-md hover:bg-rose-50 transition-colors cursor-pointer"
                            >
                              <ClipboardMinus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile & Tablet Touch-Friendly Floor Cards */}
          <div className="lg:hidden space-y-3">
            {filteredSkus.map((sku) => {
              const total = getTotalStock(sku);
              const rop = calculateROP(sku);
              const status = getStockStatus(sku);
              const cover = getDaysOfCover(sku);
              const recQty = getRecommendedOrderQty(sku);

              return (
                <article
                  key={sku.id}
                  className="bg-white border border-slate-200 rounded-xl p-4 space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h3 className="text-sm font-semibold text-slate-900 leading-snug">
                        {sku.name}
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5 font-mono tabular-nums">
                        {sku.skuCode} · {sku.packSize} · {sku.aisle} - {sku.bay}
                      </p>
                    </div>
                    <span className="font-mono text-sm font-semibold text-slate-900 tabular-nums shrink-0">
                      {formatINR(sku.mrp)}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <StatusBadge status={status} inTransit={sku.inTransit} />
                    <span className="text-xs font-mono text-slate-500 tabular-nums">
                      Class {sku.abcTier}{sku.vedClass} · {cover}d cover
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 py-2.5 border-y border-slate-100 text-center tabular-nums">
                    <div>
                      <p className="text-[11px] text-slate-500">Shelf</p>
                      <p
                        className={`text-sm font-mono font-semibold ${
                          sku.shelfStock === 0 ? 'text-rose-600' : 'text-slate-900'
                        }`}
                      >
                        {sku.shelfStock}
                        <span className="text-xs font-normal text-slate-400">
                          /{sku.shelfCapacity}
                        </span>
                      </p>
                    </div>
                    <div>
                      <p className="text-[11px] text-slate-500">Backroom</p>
                      <p className="text-sm font-mono font-semibold text-slate-900">
                        {sku.backroomStock}
                      </p>
                    </div>
                    <div>
                      <p className="text-[11px] text-slate-500">Total / ROP</p>
                      <p className="text-sm font-mono font-semibold text-slate-900">
                        {total}
                        <span className="text-xs font-normal text-slate-400"> / {rop}</span>
                      </p>
                    </div>
                  </div>

                  {/* Touch-Friendly Floor Action Buttons (min 44px height) */}
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => recordSale(sku.id)}
                      disabled={sku.shelfStock === 0}
                      className="min-h-[44px] inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-800 bg-slate-50 border border-slate-200 rounded-lg active:bg-slate-100 disabled:opacity-40 cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>-1 Sale</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => restockShelf(sku.id)}
                      disabled={sku.backroomStock === 0}
                      className="min-h-[44px] inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg active:bg-emerald-100 disabled:opacity-40 cursor-pointer"
                    >
                      <PackagePlus className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>+Restock Shelf</span>
                    </button>

                    {sku.inTransit ? (
                      <button
                        type="button"
                        onClick={() => receiveDCShipment(sku.id)}
                        className="min-h-[44px] inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-sky-800 bg-sky-50 border border-sky-200 rounded-lg cursor-pointer"
                      >
                        <PackageCheck className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Receive DC (+{sku.inTransitQty})</span>
                      </button>
                    ) : status !== 'Optimal' ? (
                      <button
                        type="button"
                        onClick={() => createDCOrder(sku.id)}
                        className="min-h-[44px] inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg cursor-pointer"
                      >
                        <Truck className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Order DC (+{recQty})</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => receiveDCShipment(sku.id)}
                        className="min-h-[44px] inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg cursor-pointer"
                      >
                        <Truck className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>+Receive DC</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => openShrinkageModal(sku.id)}
                      className="min-h-[44px] inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-rose-700 bg-white border border-slate-200 rounded-lg cursor-pointer"
                    >
                      <ClipboardMinus className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Log Shrinkage</span>
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
};
