import React, { useEffect, useState } from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { useInventory } from '../context/InventoryContext';
import { ShrinkageReason } from '../types/inventory';
import { formatINR } from '../utils/inventoryMath';

const REASONS: ShrinkageReason[] = [
  'Damaged in Handling',
  'Expired / Write-off',
  'Missing / Pilferage',
  'Spillage / Torn Pack',
];

export const ShrinkageModal: React.FC = () => {
  const { state, closeShrinkageModal, logShrinkage } = useInventory();
  const [selectedSkuId, setSelectedSkuId] = useState<string>('');
  const [location, setLocation] = useState<'Shelf' | 'Backroom'>('Shelf');
  const [quantity, setQuantity] = useState<number>(1);
  const [reason, setReason] = useState<ShrinkageReason>('Damaged in Handling');
  const [note, setNote] = useState('');
  const [loggedBy, setLoggedBy] = useState('A. Verma (Floor Lead)');

  useEffect(() => {
    if (state.shrinkageModalOpen) {
      const targetId =
        state.shrinkageTargetSkuId ||
        state.skus.find((s) => s.shelfStock > 0 || s.backroomStock > 0)?.id ||
        state.skus[0]?.id ||
        '';
      setSelectedSkuId(targetId);

      const targetSku = state.skus.find((s) => s.id === targetId);
      if (targetSku) {
        setLocation(targetSku.shelfStock > 0 ? 'Shelf' : 'Backroom');
      }
      setQuantity(1);
      setReason('Damaged in Handling');
      setNote('');
    }
  }, [state.shrinkageModalOpen, state.shrinkageTargetSkuId, state.skus]);

  if (!state.shrinkageModalOpen) return null;

  const activeSku = state.skus.find((s) => s.id === selectedSkuId);
  const maxAvailable = activeSku
    ? location === 'Shelf'
      ? activeSku.shelfStock
      : activeSku.backroomStock
    : 0;
  const estLoss = activeSku ? Math.min(quantity, maxAvailable) * activeSku.unitCost : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSku || maxAvailable <= 0 || quantity <= 0) return;
    logShrinkage({
      skuId: activeSku.id,
      location,
      quantity,
      reason,
      note,
      loggedBy,
    });
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="shrinkage-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-end bg-slate-900/40 backdrop-blur-[1px]"
    >
      <div className="w-full max-w-md h-full bg-white border-l border-slate-200 shadow-xl flex flex-col">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 id="shrinkage-modal-title" className="text-lg font-bold text-slate-900">
              Log Inventory Shrinkage
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Deduct damaged, expired, or unaccounted units from live store stock
            </p>
          </div>
          <button
            type="button"
            onClick={closeShrinkageModal}
            aria-label="Close shrinkage drawer"
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* SKU Selector */}
          <div>
            <label htmlFor="shrinkage-sku" className="block text-xs font-semibold text-slate-700 mb-1.5">
              Select SKU
            </label>
            <select
              id="shrinkage-sku"
              value={selectedSkuId}
              onChange={(e) => setSelectedSkuId(e.target.value)}
              className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:bg-white focus:border-slate-900"
            >
              {state.skus.map((sku) => (
                <option key={sku.id} value={sku.id}>
                  {sku.skuCode} · {sku.name} ({sku.packSize})
                </option>
              ))}
            </select>
            {activeSku && (
              <p className="mt-1.5 text-xs text-slate-500 font-mono tabular-nums">
                Available — Shelf: {activeSku.shelfStock} · Backroom: {activeSku.backroomStock} · Cost: {formatINR(activeSku.unitCost)}/unit
              </p>
            )}
          </div>

          {/* Deduct Location */}
          <div>
            <span className="block text-xs font-semibold text-slate-700 mb-1.5">
              Audit Location
            </span>
            <div className="grid grid-cols-2 gap-2">
              {(['Shelf', 'Backroom'] as const).map((loc) => {
                const count = activeSku
                  ? loc === 'Shelf'
                    ? activeSku.shelfStock
                    : activeSku.backroomStock
                  : 0;
                return (
                  <button
                    key={loc}
                    type="button"
                    onClick={() => setLocation(loc)}
                    className={`px-3 py-2.5 text-sm font-medium rounded-lg border text-left transition-colors cursor-pointer ${
                      location === loc
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div>{loc}</div>
                    <div
                      className={`text-xs font-mono tabular-nums ${
                        location === loc ? 'text-slate-300' : 'text-slate-500'
                      }`}
                    >
                      {count} units available
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quantity & Reason */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="shrinkage-qty" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Units Lost
              </label>
              <input
                id="shrinkage-qty"
                type="number"
                min={1}
                max={Math.max(1, maxAvailable)}
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value, 10) || 1))}
                className="w-full px-3 py-2.5 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:bg-white focus:border-slate-900"
              />
            </div>

            <div>
              <label htmlFor="shrinkage-reason" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Shrinkage Reason
              </label>
              <select
                id="shrinkage-reason"
                value={reason}
                onChange={(e) => setReason(e.target.value as ShrinkageReason)}
                className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:bg-white focus:border-slate-900"
              >
                {REASONS.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Staff & Audit Note */}
          <div>
            <label htmlFor="shrinkage-staff" className="block text-xs font-semibold text-slate-700 mb-1.5">
              Logged By
            </label>
            <input
              id="shrinkage-staff"
              type="text"
              value={loggedBy}
              onChange={(e) => setLoggedBy(e.target.value)}
              className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:bg-white focus:border-slate-900"
            />
          </div>

          <div>
            <label htmlFor="shrinkage-note" className="block text-xs font-semibold text-slate-700 mb-1.5">
              Audit Remarks (Optional)
            </label>
            <textarea
              id="shrinkage-note"
              rows={2}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="e.g. Torn outer pouch near bottom pallet..."
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-slate-900"
            />
          </div>

          {/* Loss Summary */}
          <div className="p-3.5 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-medium text-rose-800">
              <AlertTriangle className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>Write-off Cost Impact</span>
            </div>
            <span className="text-sm font-mono font-bold text-rose-800 tabular-nums">
              {formatINR(estLoss)}
            </span>
          </div>

          {maxAvailable === 0 && (
            <p className="text-xs font-medium text-amber-700">
              Selected location has 0 units. Switch between Shelf and Backroom or choose another SKU.
            </p>
          )}
        </form>

        <div className="px-6 py-4 border-t border-slate-200 flex items-center justify-end gap-2.5 bg-slate-50">
          <button
            type="button"
            onClick={closeShrinkageModal}
            className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!activeSku || maxAvailable === 0}
            className="px-4 py-2 text-sm font-medium text-white bg-rose-600 rounded-lg hover:bg-rose-700 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            Confirm Write-off
          </button>
        </div>
      </div>
    </div>
  );
};
