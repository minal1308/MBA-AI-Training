export type Category =
  | 'Staples'
  | 'FMCG'
  | 'Dairy'
  | 'Home Care'
  | 'General Merchandise';

export type ABCTier = 'A' | 'B' | 'C';
export type VEDClass = 'V' | 'E' | 'D';

export type StockStatus = 'Optimal' | 'Low Stock' | 'Critical' | 'Out of Stock';

export type ShrinkageReason =
  | 'Damaged in Handling'
  | 'Expired / Write-off'
  | 'Missing / Pilferage'
  | 'Spillage / Torn Pack';

export type AppMode = 'staff' | 'kiosk';
export type StaffTab = 'overview' | 'tracker' | 'replenishment' | 'audit';

export interface SKU {
  id: string;
  skuCode: string;
  barcode: string;
  name: string;
  brand: string;
  packSize: string;
  category: Category;
  subType: string;
  aisle: string;
  bay: string;
  shelfLevel: string;
  mrp: number;
  unitCost: number;
  shelfStock: number;
  shelfCapacity: number;
  backroomStock: number;
  avgDailySales: number;
  leadTimeDays: number;
  safetyStock: number;
  maxStock: number;
  abcTier: ABCTier;
  vedClass: VEDClass;
  inTransit: boolean;
  inTransitQty: number;
  dcOrderId?: string;
  dcLeadTimeWindow?: '24 hrs' | '48 hrs';
  orderedAt?: string;
}

export interface ShrinkageEntry {
  id: string;
  skuId: string;
  skuCode: string;
  productName: string;
  category: Category;
  location: 'Shelf' | 'Backroom';
  quantity: number;
  unitCost: number;
  totalLossValue: number;
  reason: ShrinkageReason;
  note: string;
  timestamp: string;
  loggedBy: string;
}

export interface ToastMessage {
  id: string;
  title: string;
  detail?: string;
  tone: 'success' | 'warning' | 'danger' | 'info';
}

export interface InventoryFilters {
  search: string;
  category: Category | 'All';
  status: StockStatus | 'All' | 'In Transit';
  abc: ABCTier | 'All';
  ved: VEDClass | 'All';
}
