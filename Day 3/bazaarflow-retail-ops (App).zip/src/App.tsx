/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CustomerKiosk } from './components/CustomerKiosk';
import { ExecutiveDashboard } from './components/ExecutiveDashboard';
import { Header } from './components/Header';
import { OfflineIndicator } from './components/OfflineIndicator';
import { ReplenishmentEngine } from './components/ReplenishmentEngine';
import { ShrinkageAuditView } from './components/ShrinkageAuditView';
import { ShrinkageModal } from './components/ShrinkageModal';
import { StockTracker } from './components/StockTracker';
import { ToastContainer } from './components/ToastContainer';
import { InventoryProvider, useInventory } from './context/InventoryContext';

const MainWorkspace: React.FC = () => {
  const { state } = useInventory();

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Header />

      <main className="flex-1 w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {state.mode === 'kiosk' ? (
          <CustomerKiosk />
        ) : state.activeTab === 'overview' ? (
          <ExecutiveDashboard />
        ) : state.activeTab === 'tracker' ? (
          <StockTracker />
        ) : state.activeTab === 'replenishment' ? (
          <ReplenishmentEngine />
        ) : (
          <ShrinkageAuditView />
        )}
      </main>

      <ShrinkageModal />
      <OfflineIndicator />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <InventoryProvider>
      <MainWorkspace />
    </InventoryProvider>
  );
}
