import { ABCTier, SKU, StockStatus, VEDClass } from '../types/inventory';

/**
 * Standard retail Reorder Point formula:
 * ROP = (Average Daily Sales * Lead Time in Days) + Safety Stock
 */
export function calculateROP(sku: Pick<SKU, 'avgDailySales' | 'leadTimeDays' | 'safetyStock'>): number {
  return Math.ceil(sku.avgDailySales * sku.leadTimeDays + sku.safetyStock);
}

export function getTotalStock(sku: Pick<SKU, 'shelfStock' | 'backroomStock'>): number {
  return sku.shelfStock + sku.backroomStock;
}

/**
 * Determines stock health status:
 * - Out of Stock: Total Stock === 0
 * - Critical: Vital (V) item below 50% of ROP, or Category A at 0 shelf stock
 * - Low Stock: Total Stock <= ROP
 * - Optimal: Total Stock > ROP
 */
export function getStockStatus(sku: SKU): StockStatus {
  const total = getTotalStock(sku);
  const rop = calculateROP(sku);

  if (total === 0) {
    return 'Out of Stock';
  }

  if (sku.vedClass === 'V' && total < rop * 0.5) {
    return 'Critical';
  }

  if (total <= rop) {
    return 'Low Stock';
  }

  return 'Optimal';
}

export function isCriticalStockout(sku: SKU): boolean {
  const total = getTotalStock(sku);
  return total === 0 && (sku.vedClass === 'V' || sku.abcTier === 'A');
}

export function isPendingReplenishment(sku: SKU): boolean {
  const total = getTotalStock(sku);
  const rop = calculateROP(sku);
  return total <= rop;
}

export function getDaysOfCover(sku: Pick<SKU, 'shelfStock' | 'backroomStock' | 'avgDailySales'>): number {
  const total = getTotalStock(sku);
  if (sku.avgDailySales <= 0) return 99;
  return Number((total / sku.avgDailySales).toFixed(1));
}

export function getRecommendedOrderQty(sku: SKU): number {
  const total = getTotalStock(sku);
  const effectiveStock = total + (sku.inTransit ? sku.inTransitQty : 0);
  const deficit = sku.maxStock - effectiveStock;
  return Math.max(12, Math.ceil(deficit / 6) * 6);
}

export function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatINRLakhs(amount: number): string {
  const lakhs = amount / 100000;
  return `₹${lakhs.toFixed(2)} L`;
}

export function getABCVEDLabel(abc: ABCTier, ved: VEDClass): string {
  const abcText: Record<ABCTier, string> = {
    A: 'High Value',
    B: 'Medium Value',
    C: 'Low Value',
  };
  const vedText: Record<VEDClass, string> = {
    V: 'Vital',
    E: 'Essential',
    D: 'Desirable',
  };
  return `${abc}${ved} · ${abcText[abc]} / ${vedText[ved]}`;
}

export function getKioskAvailability(sku: SKU): {
  label: 'Available on Shelf' | 'Limited Stock' | 'Out of Stock';
  note: string;
  tone: 'emerald' | 'amber' | 'rose';
} {
  if (sku.shelfStock > 5) {
    return {
      label: 'Available on Shelf',
      note: `${sku.shelfStock} packs ready on shelf`,
      tone: 'emerald',
    };
  }
  if (sku.shelfStock > 0) {
    return {
      label: 'Limited Stock',
      note: `Only ${sku.shelfStock} left on shelf`,
      tone: 'amber',
    };
  }
  if (sku.backroomStock > 0) {
    return {
      label: 'Out of Stock',
      note: 'Shelf empty — ask floor associate for backroom check',
      tone: 'rose',
    };
  }
  return {
    label: 'Out of Stock',
    note: sku.inTransit ? 'Restock arriving within 24–48 hrs' : 'Currently unavailable at this store',
    tone: 'rose',
  };
}

export function findKioskAlternatives(target: SKU, allSkus: SKU[]): SKU[] {
  return allSkus
    .filter((item) => item.id !== target.id && item.shelfStock > 0)
    .sort((a, b) => {
      const aSameSub = a.subType === target.subType ? 2 : a.category === target.category ? 1 : 0;
      const bSameSub = b.subType === target.subType ? 2 : b.category === target.category ? 1 : 0;
      if (bSameSub !== aSameSub) return bSameSub - aSameSub;
      return b.shelfStock - a.shelfStock;
    })
    .filter((item) => item.subType === target.subType || item.category === target.category)
    .slice(0, 3);
}
