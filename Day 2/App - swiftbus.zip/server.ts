import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { INITIAL_BOOKINGS, MOCK_BUSES } from './src/data/mockData.ts';
import type { BookingRecord } from './src/types/index.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const bookingsStore: BookingRecord[] = [...INITIAL_BOOKINGS];

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Search, filter & sort buses
  app.get('/api/buses', (req, res) => {
    const origin = String(req.query.origin || '').trim().toLowerCase();
    const destination = String(req.query.destination || '').trim().toLowerCase();
    const sortBy = String(req.query.sortBy || 'earliest');

    let results = MOCK_BUSES.filter((bus) => {
      const matchOrigin = origin ? bus.origin.toLowerCase() === origin : true;
      const matchDest = destination ? bus.destination.toLowerCase() === destination : true;
      return matchOrigin && matchDest;
    });

    if (sortBy === 'cheapest') {
      results = [...results].sort((a, b) => a.startingPrice - b.startingPrice);
    } else if (sortBy === 'fastest') {
      results = [...results].sort((a, b) => a.durationMinutes - b.durationMinutes);
    } else if (sortBy === 'rating') {
      results = [...results].sort((a, b) => b.rating - a.rating);
    } else {
      results = [...results].sort((a, b) => a.departureTime.localeCompare(b.departureTime));
    }

    res.json({ count: results.length, buses: results });
  });

  // Fetch all bookings
  app.get('/api/bookings', (_req, res) => {
    res.json({ bookings: bookingsStore });
  });

  // Create booking
  app.post('/api/bookings', (req, res) => {
    const body = req.body;
    if (!body || !body.busId || !Array.isArray(body.seats) || body.seats.length === 0) {
      res.status(400).json({ error: 'Invalid booking payload' });
      return;
    }

    const pnr = body.pnr || `SB${Math.floor(100000 + Math.random() * 900000)}`;
    const newRecord: BookingRecord = {
      ...body,
      pnr,
      status: 'UPCOMING',
      createdAt: new Date().toISOString(),
    };

    bookingsStore.unshift(newRecord);
    res.status(201).json({ success: true, pnr, booking: newRecord });
  });

  // Cancel booking
  app.patch('/api/bookings/:pnr/cancel', (req, res) => {
    const pnr = String(req.params.pnr || '').toUpperCase();
    const refundAmount = Number(req.body?.refundAmount || 0);
    const idx = bookingsStore.findIndex((b) => b.pnr.toUpperCase() === pnr);

    if (idx === -1) {
      res.status(404).json({ error: 'Booking not found' });
      return;
    }

    bookingsStore[idx] = {
      ...bookingsStore[idx],
      status: 'CANCELLED',
      refundAmount,
    };

    res.json({ success: true, booking: bookingsStore[idx] });
  });

  // Live GPS Tracking Lookup by PNR or Bus Number
  app.get('/api/tracking/:query', (req, res) => {
    const normalized = decodeURIComponent(req.params.query || '').trim().toUpperCase();

    const matchedBooking = bookingsStore.find((b) => b.pnr.toUpperCase() === normalized);
    const bus = matchedBooking
      ? MOCK_BUSES.find((b) => b.id === matchedBooking.busId)
      : MOCK_BUSES.find((b) => b.busNumber.toUpperCase() === normalized);

    if (!bus) {
      res.status(404).json({ error: 'No active bus found for this PNR or Bus Number.' });
      return;
    }

    res.json({
      pnr: matchedBooking?.pnr || null,
      busNumber: bus.busNumber,
      operatorName: bus.operatorName,
      busType: bus.busType,
      origin: bus.origin,
      destination: bus.destination,
      departureTime: bus.departureTime,
      arrivalTime: bus.arrivalTime,
      driverName: bus.driverName,
      driverPhone: bus.driverPhone,
      currentDelayMins: bus.currentDelayMins,
      routeCoordinates: bus.routeCoordinates,
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SwiftBus server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
