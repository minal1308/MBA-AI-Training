import { create } from 'zustand';
import {
  AppPage,
  BookingRecord,
  Bus,
  Passenger,
  RoutePoint,
  SeatItem,
  ToastMessage,
} from '../types';
import { INITIAL_BOOKINGS, PROMO_CODES } from '../data/mockData';

interface SearchQuery {
  origin: string;
  destination: string;
  travelDate: string;
}

interface BookingState {
  // Navigation
  currentPage: AppPage;
  activeTicketPnr: string | null;
  trackingQuery: string;
  navigate: (page: AppPage, opts?: { pnr?: string; trackingQuery?: string }) => void;

  // Search State
  searchQuery: SearchQuery;
  setSearchQuery: (query: Partial<SearchQuery>) => void;

  // Active Selection State
  selectedBus: Bus | null;
  selectedSeats: SeatItem[];
  selectedBoardingPoint: RoutePoint | null;
  selectedDroppingPoint: RoutePoint | null;
  passengers: Passenger[];
  contactEmail: string;
  contactPhone: string;
  appliedPromoCode: string | null;
  discountAmount: number;

  // Bookings History
  bookings: BookingRecord[];
  fetchBookings: () => Promise<void>;

  // Toast Notifications
  toasts: ToastMessage[];
  addToast: (type: ToastMessage['type'], message: string) => void;
  removeToast: (id: string) => void;

  // Actions
  selectBusForBooking: (bus: Bus) => void;
  toggleSeat: (seat: SeatItem) => void;
  setBoardingPoint: (point: RoutePoint) => void;
  setDroppingPoint: (point: RoutePoint) => void;
  initializePassengers: () => void;
  updatePassenger: (seatId: string, field: keyof Passenger, value: string) => void;
  setContactInfo: (email: string, phone: string) => void;
  applyPromo: (code: string) => boolean;
  removePromo: () => void;
  confirmBooking: (paymentMethod: string) => Promise<BookingRecord>;
  cancelBooking: (pnr: string, refundAmount: number) => Promise<void>;
  resetActiveBooking: () => void;
}

const todayISO = () => new Date().toISOString().split('T')[0];

export const useBookingStore = create<BookingState>((set, get) => ({
  currentPage: 'home',
  activeTicketPnr: null,
  trackingQuery: 'SB849201',

  navigate: (page, opts) => {
    set((state) => ({
      currentPage: page,
      activeTicketPnr: opts?.pnr ?? state.activeTicketPnr,
      trackingQuery: opts?.trackingQuery ?? state.trackingQuery,
    }));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  searchQuery: {
    origin: 'Mumbai',
    destination: 'Pune',
    travelDate: todayISO(),
  },

  setSearchQuery: (query) =>
    set((state) => ({
      searchQuery: { ...state.searchQuery, ...query },
    })),

  selectedBus: null,
  selectedSeats: [],
  selectedBoardingPoint: null,
  selectedDroppingPoint: null,
  passengers: [],
  contactEmail: '',
  contactPhone: '',
  appliedPromoCode: null,
  discountAmount: 0,

  bookings: INITIAL_BOOKINGS,

  fetchBookings: async () => {
    try {
      const res = await fetch('/api/bookings');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.bookings)) {
          set({ bookings: data.bookings });
        }
      }
    } catch {
      // Keep local initial bookings if offline
    }
  },

  toasts: [],

  addToast: (type, message) => {
    const id = Math.random().toString(36).slice(2, 9);
    set((state) => ({ toasts: [...state.toasts, { id, type, message }] }));
    setTimeout(() => {
      get().removeToast(id);
    }, 3600);
  },

  removeToast: (id) =>
    set((state) => ({
      toasts: state.toasts.filter((t) => t.id !== id),
    })),

  selectBusForBooking: (bus) =>
    set({
      selectedBus: bus,
      selectedSeats: [],
      selectedBoardingPoint: bus.boardingPoints[0] || null,
      selectedDroppingPoint: bus.droppingPoints[0] || null,
      passengers: [],
      appliedPromoCode: null,
      discountAmount: 0,
    }),

  toggleSeat: (seat) => {
    if (seat.status === 'BOOKED') {
      get().addToast('error', `Seat ${seat.label} is already booked.`);
      return;
    }

    const { selectedSeats, addToast } = get();
    const exists = selectedSeats.some((s) => s.id === seat.id);

    if (exists) {
      set({ selectedSeats: selectedSeats.filter((s) => s.id !== seat.id) });
      return;
    }

    if (selectedSeats.length >= 6) {
      addToast('error', 'Maximum 6 seats allowed per booking.');
      return;
    }

    if (seat.status === 'LADIES') {
      addToast('info', `Seat ${seat.label} is reserved for female passengers.`);
    }

    set({ selectedSeats: [...selectedSeats, seat] });
  },

  setBoardingPoint: (point) => set({ selectedBoardingPoint: point }),
  setDroppingPoint: (point) => set({ selectedDroppingPoint: point }),

  initializePassengers: () => {
    const { selectedSeats, passengers } = get();
    const updated: Passenger[] = selectedSeats.map((seat) => {
      const existing = passengers.find((p) => p.seatId === seat.id);
      return (
        existing || {
          seatId: seat.id,
          seatLabel: seat.label,
          name: '',
          age: '',
          gender: seat.status === 'LADIES' ? 'Female' : 'Male',
        }
      );
    });
    set({ passengers: updated });
  },

  updatePassenger: (seatId, field, value) =>
    set((state) => ({
      passengers: state.passengers.map((p) =>
        p.seatId === seatId ? { ...p, [field]: value } : p
      ),
    })),

  setContactInfo: (email, phone) =>
    set({ contactEmail: email, contactPhone: phone }),

  applyPromo: (code) => {
    const normalized = code.trim().toUpperCase();
    const promo = PROMO_CODES.find((p) => p.code === normalized);
    const { selectedSeats, addToast } = get();

    if (!promo) {
      addToast('error', 'Invalid promo code. Try FIRST20, WEEKEND10, or VOLVO15.');
      return false;
    }

    const baseFare = selectedSeats.reduce((sum, s) => sum + s.price, 0);
    const rawDiscount = Math.round((baseFare * promo.discountPercent) / 100);
    const discountAmount = Math.min(rawDiscount, promo.maxDiscount);

    set({ appliedPromoCode: promo.code, discountAmount });
    addToast('success', `Promo ${promo.code} applied. You saved ₹${discountAmount}.`);
    return true;
  },

  removePromo: () => set({ appliedPromoCode: null, discountAmount: 0 }),

  confirmBooking: async (paymentMethod) => {
    const state = get();
    const bus = state.selectedBus!;
    const baseFare = state.selectedSeats.reduce((sum, s) => sum + s.price, 0);
    const gstAmount = Math.round(baseFare * 0.05);
    const totalAmount = Math.max(0, baseFare + gstAmount - state.discountAmount);
    const pnr = `SB${Math.floor(100000 + Math.random() * 900000)}`;

    const payload: BookingRecord = {
      pnr,
      busId: bus.id,
      busNumber: bus.busNumber,
      operatorName: bus.operatorName,
      busType: bus.busType,
      origin: bus.origin,
      destination: bus.destination,
      travelDate: state.searchQuery.travelDate,
      departureTime: bus.departureTime,
      arrivalTime: bus.arrivalTime,
      boardingPoint: state.selectedBoardingPoint!,
      droppingPoint: state.selectedDroppingPoint!,
      seats: state.selectedSeats.map((s) => s.label),
      passengers: state.passengers,
      contactEmail: state.contactEmail,
      contactPhone: state.contactPhone,
      baseFare,
      gstAmount,
      discountAmount: state.discountAmount,
      totalAmount,
      paymentMethod,
      status: 'UPCOMING',
      zeroCancellation: bus.zeroCancellation,
      createdAt: new Date().toISOString(),
    };

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.booking) {
          set((prev) => ({
            bookings: [data.booking, ...prev.bookings],
            activeTicketPnr: data.booking.pnr,
          }));
          return data.booking;
        }
      }
    } catch {
      // Fallback to local state persistence
    }

    set((prev) => ({
      bookings: [payload, ...prev.bookings],
      activeTicketPnr: payload.pnr,
    }));

    return payload;
  },

  cancelBooking: async (pnr, refundAmount) => {
    try {
      await fetch(`/api/bookings/${encodeURIComponent(pnr)}/cancel`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refundAmount }),
      });
    } catch {
      // Update locally regardless
    }

    set((state) => ({
      bookings: state.bookings.map((b) =>
        b.pnr === pnr ? { ...b, status: 'CANCELLED', refundAmount } : b
      ),
    }));
    get().addToast('success', `Booking ${pnr} cancelled. Refund of ₹${refundAmount} initiated.`);
  },

  resetActiveBooking: () =>
    set({
      selectedBus: null,
      selectedSeats: [],
      passengers: [],
      appliedPromoCode: null,
      discountAmount: 0,
    }),
}));
