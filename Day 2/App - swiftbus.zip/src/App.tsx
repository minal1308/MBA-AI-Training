import { useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ToastContainer } from './components/ToastContainer';
import { LandingPage } from './pages/LandingPage';
import { SearchResultsPage } from './pages/SearchResultsPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { TicketPage } from './pages/TicketPage';
import { TrackBusPage } from './pages/TrackBusPage';
import { BookingsPage } from './pages/BookingsPage';
import { useBookingStore } from './store/useBookingStore';

export default function App() {
  const { currentPage, fetchBookings } = useBookingStore();

  useEffect(() => {
    fetchBookings();
  }, [fetchBookings]);

  return (
    <div className="flex min-h-screen flex-col bg-[#F8FAFC] text-slate-900">
      <Navbar />
      <main className="flex-1">
        {currentPage === 'home' && <LandingPage />}
        {currentPage === 'search' && <SearchResultsPage />}
        {currentPage === 'checkout' && <CheckoutPage />}
        {currentPage === 'ticket' && <TicketPage />}
        {currentPage === 'track' && <TrackBusPage />}
        {currentPage === 'bookings' && <BookingsPage />}
      </main>
      <footer className="no-print border-t border-slate-200 bg-white py-6">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-4 text-xs text-slate-500 sm:px-6">
          <span className="font-display font-bold text-slate-900">SwiftBus</span>
          <span>
            © {new Date().getFullYear()} SwiftBus Mobility · Verified Intercity Operators · 24/7 Live Highway GPS
          </span>
        </div>
      </footer>
      <ToastContainer />
    </div>
  );
}
