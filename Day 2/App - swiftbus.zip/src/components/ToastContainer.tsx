import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';
import { useBookingStore } from '../store/useBookingStore';

export function ToastContainer() {
  const { toasts, removeToast } = useBookingStore();

  if (toasts.length === 0) return null;

  return (
    <div className="no-print fixed bottom-4 right-4 z-50 flex max-w-sm flex-col gap-2">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          role="status"
          className={`flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-medium shadow-lg transition-all ${
            toast.type === 'success'
              ? 'border-emerald-200 bg-emerald-50 text-emerald-950'
              : toast.type === 'error'
              ? 'border-rose-200 bg-rose-50 text-rose-950'
              : 'border-sky-200 bg-sky-50 text-sky-950'
          }`}
        >
          {toast.type === 'success' && (
            <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-600" />
          )}
          {toast.type === 'error' && (
            <AlertCircle className="h-5 w-5 shrink-0 text-rose-600" />
          )}
          {toast.type === 'info' && (
            <Info className="h-5 w-5 shrink-0 text-sky-600" />
          )}
          <span className="flex-1">{toast.message}</span>
          <button
            type="button"
            onClick={() => removeToast(toast.id)}
            aria-label="Dismiss notification"
            className="rounded p-1 opacity-60 hover:opacity-100 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ))}
    </div>
  );
}
