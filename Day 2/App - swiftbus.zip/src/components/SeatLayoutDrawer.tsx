import { useState } from 'react';
import { ArrowRight, Disc, MapPin, X } from 'lucide-react';
import { useBookingStore } from '../store/useBookingStore';
import type { Bus, SeatItem } from '../types';

interface Props {
  bus: Bus;
  onClose: () => void;
}

export function SeatLayoutDrawer({ bus, onClose }: Props) {
  const {
    selectedSeats,
    selectedBoardingPoint,
    selectedDroppingPoint,
    toggleSeat,
    setBoardingPoint,
    setDroppingPoint,
    initializePassengers,
    navigate,
    addToast,
  } = useBookingStore();

  const isSleeperLayout = bus.layoutType === '2+1_SLEEPER';
  const [activeDeck, setActiveDeck] = useState<'LOWER' | 'UPPER'>('LOWER');

  const deckSeats = bus.seats.filter((s) => s.deck === activeDeck);
  const rows = Array.from(new Set(deckSeats.map((s) => s.row))).sort((a, b) => a - b);

  const totalBaseFare = selectedSeats.reduce((sum, s) => sum + s.price, 0);

  const handleProceed = () => {
    if (selectedSeats.length === 0) {
      addToast('error', 'Please select at least 1 seat to proceed.');
      return;
    }
    if (!selectedBoardingPoint || !selectedDroppingPoint) {
      addToast('error', 'Please select both boarding and dropping points.');
      return;
    }
    initializePassengers();
    navigate('checkout');
  };

  const renderSeatButton = (seat: SeatItem | undefined) => {
    if (!seat) return <div className="h-11 w-11" />;

    const isSelected = selectedSeats.some((s) => s.id === seat.id);
    const isBooked = seat.status === 'BOOKED';
    const isLadies = seat.status === 'LADIES';

    let styleClass =
      'border-slate-300 bg-white text-slate-800 hover:border-emerald-600 hover:bg-emerald-50';
    if (isBooked) {
      styleClass = 'cursor-not-allowed border-slate-200 bg-slate-200 text-slate-400';
    } else if (isSelected) {
      styleClass = 'border-emerald-700 bg-emerald-600 text-white shadow-sm';
    } else if (isLadies) {
      styleClass =
        'border-pink-300 bg-pink-50 text-pink-800 hover:border-pink-500 hover:bg-pink-100';
    }

    return (
      <button
        key={seat.id}
        type="button"
        disabled={isBooked}
        onClick={() => toggleSeat(seat)}
        aria-label={`Seat ${seat.label}, ₹${seat.price}, ${seat.status.toLowerCase()}`}
        title={`Seat ${seat.label} · ₹${seat.price} (${seat.status})`}
        className={`relative flex flex-col items-center justify-center rounded-lg border-2 font-mono text-xs font-semibold tabular-nums transition active:scale-95 ${
          seat.isSleeper ? 'h-16 w-11' : 'h-11 w-11'
        } ${styleClass} ${!isBooked ? 'cursor-pointer' : ''}`}
      >
        <span>{seat.label}</span>
        {isLadies && !isSelected && (
          <span className="text-[9px] font-sans font-bold text-pink-600">F</span>
        )}
      </button>
    );
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-label="Seat Selection"
    >
      <div className="flex h-full w-full max-w-3xl flex-col bg-white shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900">
              {bus.operatorName}
            </h2>
            <p className="mt-0.5 text-xs text-slate-500 tabular-nums">
              {bus.busType} · {bus.departureTime} to {bus.arrivalTime} · {bus.duration}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close seat selection"
            className="flex h-10 w-10 items-center justify-center rounded-full text-slate-500 hover:bg-slate-100 cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Legend */}
          <div className="mb-6 flex flex-wrap items-center gap-5 border-b border-slate-100 pb-4 text-xs font-medium text-slate-600">
            <span className="flex items-center gap-2">
              <span className="h-4 w-4 rounded border-2 border-slate-300 bg-white" /> Available
            </span>
            <span className="flex items-center gap-2">
              <span className="h-4 w-4 rounded border-2 border-emerald-700 bg-emerald-600" /> Selected
            </span>
            <span className="flex items-center gap-2">
              <span className="flex h-4 w-4 items-center justify-center rounded border-2 border-pink-300 bg-pink-50 text-[9px] font-bold text-pink-700">
                F
              </span>
              Ladies Only
            </span>
            <span className="flex items-center gap-2">
              <span className="h-4 w-4 rounded border-2 border-slate-200 bg-slate-200" /> Booked
            </span>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            {/* Left: Deck Diagram */}
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">
              {isSleeperLayout && (
                <div className="mb-4 grid grid-cols-2 gap-1 rounded-lg bg-slate-200 p-1">
                  {(['LOWER', 'UPPER'] as const).map((deck) => (
                    <button
                      key={deck}
                      type="button"
                      onClick={() => setActiveDeck(deck)}
                      className={`rounded-md py-2 text-xs font-semibold transition cursor-pointer ${
                        activeDeck === deck
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {deck === 'LOWER' ? 'Lower Deck' : 'Upper Deck'}
                    </button>
                  ))}
                </div>
              )}

              {/* Driver Position */}
              <div className="mb-4 flex items-center justify-between border-b border-dashed border-slate-300 pb-2.5 text-xs text-slate-400">
                <span>Coach Front</span>
                <div className="flex items-center gap-1.5">
                  <span>Driver</span>
                  <Disc className="h-4 w-4" />
                </div>
              </div>

              {/* Seat Matrix */}
              <div className="flex flex-col items-center gap-3">
                {rows.map((rowIdx) => {
                  const rowSeats = deckSeats.filter((s) => s.row === rowIdx);
                  const left0 = rowSeats.find((s) => s.col === 0);
                  const left1 = rowSeats.find((s) => s.col === 1);
                  const right2 = rowSeats.find((s) => s.col === 2);
                  const right3 = rowSeats.find((s) => s.col === 3);

                  return (
                    <div key={rowIdx} className="flex items-center gap-3">
                      <div className="flex gap-2">
                        {renderSeatButton(left0)}
                        {!isSleeperLayout && renderSeatButton(left1)}
                      </div>
                      <div className="w-6 text-center text-[10px] text-slate-300">|</div>
                      <div className="flex gap-2">
                        {renderSeatButton(right2)}
                        {renderSeatButton(right3)}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right: Boarding & Dropping Points */}
            <div className="space-y-6">
              <div>
                <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-slate-900">
                  <MapPin className="h-4 w-4 text-orange-600" />
                  Boarding Point
                </h3>
                <div className="space-y-2">
                  {bus.boardingPoints.map((bp) => {
                    const checked = selectedBoardingPoint?.id === bp.id;
                    return (
                      <label
                        key={bp.id}
                        className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3.5 transition ${
                          checked
                            ? 'border-orange-500 bg-orange-50/50'
                            : 'border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name="boardingPoint"
                          checked={checked}
                          onChange={() => setBoardingPoint(bp)}
                          className="mt-1 accent-orange-600"
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between text-sm font-semibold text-slate-900">
                            <span>{bp.name}</span>
                            <span className="font-mono text-xs text-orange-700 tabular-nums">
                              {bp.time}
                            </span>
                          </div>
                          <p className="mt-0.5 text-xs text-slate-500">{bp.landmark}</p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div>
                <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-slate-900">
                  <MapPin className="h-4 w-4 text-emerald-600" />
                  Dropping Point
                </h3>
                <div className="space-y-2">
                  {bus.droppingPoints.map((dp) => {
                    const checked = selectedDroppingPoint?.id === dp.id;
                    return (
                      <label
                        key={dp.id}
                        className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3.5 transition ${
                          checked
                            ? 'border-emerald-600 bg-emerald-50/50'
                            : 'border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name="droppingPoint"
                          checked={checked}
                          onChange={() => setDroppingPoint(dp)}
                          className="mt-1 accent-emerald-600"
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between text-sm font-semibold text-slate-900">
                            <span>{dp.name}</span>
                            <span className="font-mono text-xs text-emerald-700 tabular-nums">
                              {dp.time}
                            </span>
                          </div>
                          <p className="mt-0.5 text-xs text-slate-500">{dp.landmark}</p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sticky Footer */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-slate-200 bg-slate-50 px-6 py-4">
          <div>
            <p className="text-xs font-medium text-slate-500 tabular-nums">
              Selected Seats ({selectedSeats.length}/6):{' '}
              <span className="font-mono font-bold text-slate-900">
                {selectedSeats.length > 0
                  ? selectedSeats.map((s) => s.label).join(', ')
                  : 'None'}
              </span>
            </p>
            <p className="mt-0.5 font-mono text-xl font-bold text-slate-900 tabular-nums">
              ₹{totalBaseFare}{' '}
              <span className="font-sans text-xs font-normal text-slate-500">+ 5% GST</span>
            </p>
          </div>
          <button
            type="button"
            onClick={handleProceed}
            className="flex items-center gap-2 rounded-xl bg-emerald-600 px-6 py-3 text-sm font-semibold text-white transition hover:bg-emerald-700 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Proceed to Book
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
