import { useEffect, useState } from 'react';
import { ArrowLeftRight, Calendar, MapPin, Search } from 'lucide-react';
import { CITIES } from '../data/mockData';
import { useBookingStore } from '../store/useBookingStore';

interface SearchWidgetProps {
  compact?: boolean;
  onSearchExecuted?: () => void;
}

export function SearchWidget({ compact = false, onSearchExecuted }: SearchWidgetProps) {
  const { searchQuery, setSearchQuery, navigate, addToast } = useBookingStore();

  const [origin, setOrigin] = useState(searchQuery.origin);
  const [destination, setDestination] = useState(searchQuery.destination);
  const [travelDate, setTravelDate] = useState(searchQuery.travelDate);
  const [showOriginList, setShowOriginList] = useState(false);
  const [showDestList, setShowDestList] = useState(false);

  useEffect(() => {
    setOrigin(searchQuery.origin);
    setDestination(searchQuery.destination);
    setTravelDate(searchQuery.travelDate);
  }, [searchQuery]);

  const today = new Date().toISOString().split('T')[0];

  const handleSwap = () => {
    const prevOrigin = origin;
    setOrigin(destination);
    setDestination(prevOrigin);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!origin.trim() || !destination.trim()) {
      addToast('error', 'Please select both Origin and Destination cities.');
      return;
    }
    if (origin.trim().toLowerCase() === destination.trim().toLowerCase()) {
      addToast('error', 'Origin and Destination cannot be the same city.');
      return;
    }
    setSearchQuery({
      origin: origin.trim(),
      destination: destination.trim(),
      travelDate,
    });
    if (onSearchExecuted) {
      onSearchExecuted();
    } else {
      navigate('search');
    }
  };

  const filterCities = (val: string) =>
    CITIES.filter((c) => c.toLowerCase().includes(val.toLowerCase()));

  return (
    <form
      onSubmit={handleSearch}
      className={`rounded-2xl border border-slate-200 bg-white ${
        compact ? 'p-4' : 'p-5 sm:p-6 shadow-xl'
      }`}
    >
      <div className="grid grid-cols-1 items-end gap-3 lg:grid-cols-12">
        {/* Origin */}
        <div className="relative lg:col-span-4">
          <label
            htmlFor="origin-input"
            className="mb-1.5 block text-xs font-semibold text-slate-600"
          >
            Leaving From
          </label>
          <div className="flex items-center gap-2.5 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 transition focus-within:border-orange-500 focus-within:bg-white">
            <MapPin className="h-4 w-4 shrink-0 text-orange-600" />
            <input
              id="origin-input"
              type="text"
              autoComplete="off"
              value={origin}
              onFocus={() => setShowOriginList(true)}
              onBlur={() => setTimeout(() => setShowOriginList(false), 160)}
              onChange={(e) => setOrigin(e.target.value)}
              placeholder="Origin City"
              className="w-full bg-transparent text-sm font-semibold text-slate-900 outline-none placeholder:text-slate-400"
            />
          </div>
          {showOriginList && (
            <ul className="absolute left-0 right-0 top-full z-30 mt-1 max-h-52 overflow-auto rounded-xl border border-slate-200 bg-white py-1 shadow-lg">
              {filterCities(origin).length > 0 ? (
                filterCities(origin).map((city) => (
                  <li
                    key={city}
                    onMouseDown={() => {
                      setOrigin(city);
                      setShowOriginList(false);
                    }}
                    className="cursor-pointer px-4 py-2 text-sm text-slate-700 hover:bg-orange-50 hover:text-orange-700"
                  >
                    {city}
                  </li>
                ))
              ) : (
                <li className="px-4 py-2 text-xs text-slate-400">No matching cities</li>
              )}
            </ul>
          )}
        </div>

        {/* Swap Cities */}
        <div className="flex justify-center lg:col-span-1">
          <button
            type="button"
            onClick={handleSwap}
            title="Swap Cities"
            aria-label="Swap origin and destination cities"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-slate-50 text-slate-600 transition duration-200 hover:rotate-180 hover:border-orange-300 hover:bg-orange-50 hover:text-orange-600 cursor-pointer"
          >
            <ArrowLeftRight className="h-4 w-4" />
          </button>
        </div>

        {/* Destination */}
        <div className="relative lg:col-span-3">
          <label
            htmlFor="destination-input"
            className="mb-1.5 block text-xs font-semibold text-slate-600"
          >
            Going To
          </label>
          <div className="flex items-center gap-2.5 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 transition focus-within:border-orange-500 focus-within:bg-white">
            <MapPin className="h-4 w-4 shrink-0 text-emerald-600" />
            <input
              id="destination-input"
              type="text"
              autoComplete="off"
              value={destination}
              onFocus={() => setShowDestList(true)}
              onBlur={() => setTimeout(() => setShowDestList(false), 160)}
              onChange={(e) => setDestination(e.target.value)}
              placeholder="Destination City"
              className="w-full bg-transparent text-sm font-semibold text-slate-900 outline-none placeholder:text-slate-400"
            />
          </div>
          {showDestList && (
            <ul className="absolute left-0 right-0 top-full z-30 mt-1 max-h-52 overflow-auto rounded-xl border border-slate-200 bg-white py-1 shadow-lg">
              {filterCities(destination).length > 0 ? (
                filterCities(destination).map((city) => (
                  <li
                    key={city}
                    onMouseDown={() => {
                      setDestination(city);
                      setShowDestList(false);
                    }}
                    className="cursor-pointer px-4 py-2 text-sm text-slate-700 hover:bg-orange-50 hover:text-orange-700"
                  >
                    {city}
                  </li>
                ))
              ) : (
                <li className="px-4 py-2 text-xs text-slate-400">No matching cities</li>
              )}
            </ul>
          )}
        </div>

        {/* Date Picker */}
        <div className="lg:col-span-2">
          <label
            htmlFor="travel-date-input"
            className="mb-1.5 block text-xs font-semibold text-slate-600"
          >
            Travel Date
          </label>
          <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 transition focus-within:border-orange-500 focus-within:bg-white">
            <Calendar className="h-4 w-4 shrink-0 text-slate-500" />
            <input
              id="travel-date-input"
              type="date"
              min={today}
              value={travelDate}
              onChange={(e) => setTravelDate(e.target.value)}
              className="w-full bg-transparent text-sm font-semibold text-slate-900 tabular-nums outline-none"
            />
          </div>
        </div>

        {/* Submit */}
        <div className="lg:col-span-2">
          <button
            type="submit"
            className="flex h-[42px] w-full items-center justify-center gap-2 rounded-xl bg-orange-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-orange-700 active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Search className="h-4 w-4" />
            Search Buses
          </button>
        </div>
      </div>
    </form>
  );
}
