import { useEffect, useRef } from 'react';
import L from 'leaflet';
import type { RouteCoordinate } from '../types';

interface Props {
  stops: RouteCoordinate[];
  currentPosition: { lat: number; lng: number };
  busNumber: string;
}

export function LiveTrackingMap({ stops, currentPosition, busNumber }: Props) {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const busMarkerRef = useRef<L.Marker | null>(null);

  useEffect(() => {
    if (!mapContainerRef.current || stops.length === 0) return;

    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
    }

    const map = L.map(mapContainerRef.current, {
      zoomControl: true,
      scrollWheelZoom: true,
    });
    mapInstanceRef.current = map;

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(map);

    const latLngs: L.LatLngExpression[] = stops.map((s) => [s.lat, s.lng]);

    const polyline = L.polyline(latLngs, {
      color: '#0f172a',
      weight: 4,
      opacity: 0.85,
      dashArray: '8, 6',
    }).addTo(map);

    stops.forEach((stop, index) => {
      const isEndpoint = index === 0 || index === stops.length - 1;
      const fill =
        index === 0
          ? '#ea580c'
          : index === stops.length - 1
          ? '#059669'
          : '#ffffff';

      const stopIcon = L.divIcon({
        className: 'swiftbus-stop-marker',
        html: `<div style="width:${isEndpoint ? '16px' : '12px'};height:${
          isEndpoint ? '16px' : '12px'
        };border-radius:9999px;background:${fill};border:3px solid #0f172a;box-shadow:0 2px 6px rgba(0,0,0,0.25);"></div>`,
        iconSize: [16, 16],
        iconAnchor: [8, 8],
      });

      L.marker([stop.lat, stop.lng], { icon: stopIcon })
        .addTo(map)
        .bindPopup(
          `<strong>${stop.name}</strong><br/><span style="font-size:12px;color:#475569;">Scheduled +${stop.etaFromStartMins} mins</span>`
        );
    });

    const busIcon = L.divIcon({
      className: 'swiftbus-live-bus-marker',
      html: `<div style="display:flex;align-items:center;justify-content:center;width:38px;height:38px;border-radius:9999px;background:#ea580c;color:#ffffff;border:3px solid #ffffff;box-shadow:0 4px 12px rgba(234,88,12,0.55);"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 6v6"/><path d="M15 6v6"/><path d="M2 12h19.6"/><path d="M18 18h3s.5-1.7.8-2.8c.1-.4.2-.8.2-1.2 0-.4-.1-.8-.2-1.2l-1.4-5C20.1 6.8 19.1 6 18 6H4a2 2 0 0 0-2 2v10h3"/><circle cx="7" cy="18" r="2"/><path d="M9 18h5"/><circle cx="16" cy="18" r="2"/></svg></div>`,
      iconSize: [38, 38],
      iconAnchor: [19, 19],
    });

    busMarkerRef.current = L.marker([currentPosition.lat, currentPosition.lng], {
      icon: busIcon,
      zIndexOffset: 1000,
    })
      .addTo(map)
      .bindPopup(`<strong>${busNumber}</strong><br/>Live GPS Active`);

    map.fitBounds(polyline.getBounds(), { padding: [44, 44] });

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, [stops, busNumber]);

  useEffect(() => {
    if (busMarkerRef.current) {
      busMarkerRef.current.setLatLng([currentPosition.lat, currentPosition.lng]);
    }
  }, [currentPosition]);

  return (
    <div
      ref={mapContainerRef}
      className="h-[380px] w-full rounded-xl border border-slate-200 sm:h-[480px]"
    />
  );
}
