import { useState } from 'react';
import { AlertCircle, Navigation, Ticket, XCircle } from 'lucide-react';
import { useBookingStore } from '../store/useBookingStore';
import type { BookingRecord, BookingStatus } from '../types';

export function BookingsPage() {
  const { bookings, cancelBooking, navigate } = useBookingStore();
  const [activeTab, setActiveTab] = useState<BookingStatus>('UPCOMING');
  const [cancelTarget, setCancelTarget] = useState<BookingRecord | null>(null);

  const filtered = bookings.filter((b) => b.status === activeTab);

  const calculateRefundPreview = (booking: BookingRecord) => {
    if (booking.zeroCancellation) {
      return {
        percent: 100,
        amount: booking.totalAmount,
        reason: 'Eligible for Zero Cancellation Policy (100% refund)',
      };
    }
    const departureMs = new Date(`${booking.travelDate}T${booking.departureTime}:00`).getTime();
    const hoursLeft = (departureMs - Date.now()) / (1000 * 60 * 60);

    if (hoursLeft >= 24) {
      return {
        percent: 90,
        amount: Math.round(booking.totalAmount * 0.9),
        reason: 'Cancelled 24+ hours prior to departure (10% operator fee)',
      };
    }
    if (hoursLeft >= 12) {
      return {
        percent: 50,
        amount: Math.round(booking.totalAmount * 0.5),
        reason: 'Cancelled 12–24 hours prior to departure (50% operator fee)',
      };
    }
    return {
      percent: 0,
      amount: 0,
      reason: 'Within 12 hours of departure (Non-refundable)',
    };
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <h1 className="font-display mb-6 text-2xl font-bold text-slate-900">My Bookings</h1>

      {/* Tabs */}
      <div className="mb-6 inline-flex flex-wrap gap-1 rounded-xl bg-slate-200/75 p-1">
        {(
          [
            { id: 'UPCOMING', label: 'Upcoming Trips' },
            { id: 'COMPLETED', label: 'Completed Trips' },
            { id: 'CANCELLED', label: 'Cancelled Trips' },
          ] as { id: BookingStatus; label: string }[]
        ).map((tab) => {
          const count = bookings.filter((b) => b.status === tab.id).length;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`rounded-lg px-4 py-2 text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer sm:text-sm ${
                activeTab === tab.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label} ({count})
            </button>
          );
        })}
      </div>

      {/* Trip List */}
      {filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-300 bg-white p-12 text-center">
          <p className="font-display text-base font-bold text-slate-900">
            No {activeTab.toLowerCase()} trips
          </p>
          <p className="mt-1 text-sm text-slate-500">
            Search intercity routes to plan your next journey.
          </p>
          <button
            type="button"
            onClick={() => navigate('home')}
            className="mt-4 rounded-lg bg-orange-600 px-5 py-2.5 text-xs font-semibold text-white hover:bg-orange-700 cursor-pointer"
          >
            Search Buses
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((booking) => (
            <article
              key={booking.pnr}
              className="rounded-xl border border-slate-200 bg-white p-5"
            >
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4">
                <div>
                  <p className="text-xs text-slate-500 tabular-nums">
                    PNR: <span className="font-mono font-bold text-slate-900">{booking.pnr}</span> ·{' '}
                    {booking.travelDate} · {booking.departureTime}
                  </p>
                  <h2 className="font-display mt-1.5 text-lg font-bold text-slate-900">
                    {booking.origin} to {booking.destination}
                  </h2>
                  <p className="mt-0.5 text-xs text-slate-600">
                    {booking.operatorName} ({booking.busType}) · Seats:{' '}
                    <span className="font-mono font-bold text-slate-900">
                      {booking.seats.join(', ')}
                    </span>
                  </p>
                </div>

                <div className="sm:text-right">
                  <p className="text-xs text-slate-500">Fare Paid</p>
                  <p className="font-mono text-xl font-bold text-slate-900 tabular-nums">
                    ₹{booking.totalAmount}
                  </p>
                  {booking.status === 'CANCELLED' && (
                    <p className="mt-0.5 text-xs font-semibold text-emerald-700 tabular-nums">
                      Refunded: ₹{booking.refundAmount ?? 0}
                    </p>
                  )}
                </div>
              </div>

              <div className="mt-4 flex flex-wrap items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => navigate('ticket', { pnr: booking.pnr })}
                  className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  <Ticket className="h-3.5 w-3.5" /> Download Ticket
                </button>

                {booking.status === 'UPCOMING' && (
                  <>
                    <button
                      type="button"
                      onClick={() => navigate('track', { trackingQuery: booking.pnr })}
                      className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 cursor-pointer"
                    >
                      <Navigation className="h-3.5 w-3.5 text-orange-400" /> Track Live
                    </button>
                    <button
                      type="button"
                      onClick={() => setCancelTarget(booking)}
                      className="flex items-center gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-4 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-100 cursor-pointer"
                    >
                      <XCircle className="h-3.5 w-3.5" /> Cancel Booking
                    </button>
                  </>
                )}
              </div>
            </article>
          ))}
        </div>
      )}

      {/* Cancel & Automated Refund Modal */}
      {cancelTarget && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
            <div className="flex items-center gap-2.5 text-rose-600">
              <AlertCircle className="h-5 w-5" />
              <h2 className="font-display text-lg font-bold text-slate-900">
                Cancel Booking {cancelTarget.pnr}?
              </h2>
            </div>

            {(() => {
              const preview = calculateRefundPreview(cancelTarget);
              return (
                <div className="mt-4 rounded-xl bg-slate-50 p-4 text-sm">
                  <p className="text-xs font-medium text-slate-600">{preview.reason}</p>
                  <div className="mt-3 flex justify-between text-slate-700">
                    <span>Amount Paid</span>
                    <span className="font-mono tabular-nums">₹{cancelTarget.totalAmount}</span>
                  </div>
                  <div className="mt-1.5 flex justify-between font-bold text-emerald-700">
                    <span>Refund Preview ({preview.percent}%)</span>
                    <span className="font-mono tabular-nums">₹{preview.amount}</span>
                  </div>

                  <div className="mt-5 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setCancelTarget(null)}
                      className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                    >
                      Keep Ticket
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        await cancelBooking(cancelTarget.pnr, preview.amount);
                        setCancelTarget(null);
                      }}
                      className="rounded-lg bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-700 cursor-pointer"
                    >
                      Confirm Cancellation
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
}
