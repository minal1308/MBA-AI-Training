import { useCallback, useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Gauge,
  MapPin,
  Navigation,
  Phone,
  Search,
} from 'lucide-react';
import { LiveTrackingMap } from '../components/LiveTrackingMap';
import { useBookingStore } from '../store/useBookingStore';
import type { TrackingPayload } from '../types';

export function TrackBusPage() {
  const { trackingQuery } = useBookingStore();
  const [lookupInput, setLookupInput] = useState(trackingQuery || 'SB849201');
  const [trackingData, setTrackingData] = useState<TrackingPayload | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const [segmentIndex, setSegmentIndex] = useState(1);
  const [progressInSegment, setProgressInSegment] = useState(0.25);
  const [speedKmh, setSpeedKmh] = useState(68);

  const fetchTracking = useCallback(async (query: string) => {
    const trimmed = query.trim();
    if (!trimmed) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`/api/tracking/${encodeURIComponent(trimmed)}`);
      if (!res.ok) {
        const err = await res.json();
        setError(err.error || 'Bus not found');
        setTrackingData(null);
      } else {
        const data: TrackingPayload = await res.json();
        setTrackingData(data);
        setSegmentIndex(1);
        setProgressInSegment(0.2);
      }
    } catch {
      setError('Unable to reach live telemetry service.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const initial = trackingQuery || 'SB849201';
    setLookupInput(initial);
    fetchTracking(initial);
  }, [trackingQuery, fetchTracking]);

  // Simulate real-time vehicle motion every 2 seconds along the route polyline
  useEffect(() => {
    if (!trackingData || trackingData.routeCoordinates.length < 2) return;

    const timer = setInterval(() => {
      setSpeedKmh(Math.floor(58 + Math.random() * 22));
      setProgressInSegment((prev) => {
        const next = prev + 0.08;
        if (next >= 1) {
          setSegmentIndex((seg) =>
            seg + 1 >= trackingData.routeCoordinates.length - 1 ? 0 : seg + 1
          );
          return 0;
        }
        return next;
      });
    }, 2000);

    return () => clearInterval(timer);
  }, [trackingData]);

  const stops = trackingData?.routeCoordinates || [];
  const startStop = stops[segmentIndex] || stops[0];
  const nextStop = stops[Math.min(segmentIndex + 1, stops.length - 1)] || stops[0];

  const currentPosition =
    startStop && nextStop
      ? {
          lat: startStop.lat + (nextStop.lat - startStop.lat) * progressInSegment,
          lng: startStop.lng + (nextStop.lng - startStop.lng) * progressInSegment,
        }
      : { lat: 19.0178, lng: 72.8478 };

  const remainingEtaMins = nextStop
    ? Math.max(2, Math.round((1 - progressInSegment) * 35) + (trackingData?.currentDelayMins || 0))
    : 0;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      {/* Lookup Bar */}
      <div className="mb-6 rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
          <div>
            <h1 className="font-display flex items-center gap-2 text-xl font-bold text-slate-900">
              <Navigation className="h-5 w-5 text-orange-600" /> Track My Bus
            </h1>
            <p className="mt-1 text-xs text-slate-500">
              Enter your PNR Number or Bus Registration Number for live GPS highway telemetry.
            </p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              fetchTracking(lookupInput);
            }}
            className="flex w-full gap-2 md:w-auto"
          >
            <input
              type="text"
              value={lookupInput}
              onChange={(e) => setLookupInput(e.target.value)}
              placeholder="PNR or Bus Number"
              aria-label="Enter PNR or Bus Number"
              className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 font-mono text-sm font-semibold uppercase outline-none focus:border-orange-500 focus:bg-white md:w-64"
            />
            <button
              type="submit"
              disabled={loading}
              className="flex items-center gap-1.5 rounded-lg bg-orange-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-700 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Search className="h-4 w-4" /> Track
            </button>
          </form>
        </div>

        {/* Sample Lookup Buttons */}
        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-500">Active coaches:</span>
          {['SB849201', 'KA-01-SB-9600', 'DL-01-SB-5510', 'MH-14-SB-8820'].map((sample) => (
            <button
              key={sample}
              type="button"
              onClick={() => {
                setLookupInput(sample);
                fetchTracking(sample);
              }}
              className={`rounded-md border px-2.5 py-1 font-mono font-semibold transition cursor-pointer ${
                lookupInput.toUpperCase() === sample
                  ? 'border-slate-900 bg-slate-900 text-white'
                  : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-orange-400 hover:text-orange-700'
              }`}
            >
              {sample}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="mb-6 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm font-semibold text-rose-800">
          {error}
        </div>
      )}

      {trackingData && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Interactive Map */}
          <div className="lg:col-span-8">
            <LiveTrackingMap
              stops={trackingData.routeCoordinates}
              currentPosition={currentPosition}
              busNumber={trackingData.busNumber}
            />
          </div>

          {/* Telemetry Dashboard */}
          <aside className="lg:col-span-4">
            <div className="rounded-xl border border-slate-200 bg-white p-5">
              <div className="border-b border-slate-100 pb-4">
                <p className="text-xs font-semibold text-emerald-700">
                  Live GPS Stream · Updating every 2s
                </p>
                <h2 className="font-display mt-1 text-lg font-bold text-slate-900">
                  {trackingData.operatorName}
                </h2>
                <p className="mt-0.5 text-xs text-slate-500">
                  <span className="font-mono">{trackingData.busNumber}</span> ·{' '}
                  {trackingData.origin} to {trackingData.destination}
                </p>
              </div>

              {/* Delay Status */}
              <div className="mt-4">
                {trackingData.currentDelayMins === 0 ? (
                  <div className="flex items-center gap-2 rounded-lg bg-emerald-50 px-3.5 py-2.5 text-xs font-semibold text-emerald-900">
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
                    On Time · Running on scheduled corridor
                  </div>
                ) : (
                  <div className="flex items-center gap-2 rounded-lg bg-amber-50 px-3.5 py-2.5 text-xs font-semibold text-amber-900">
                    <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600" />
                    Delayed by {trackingData.currentDelayMins} mins due to traffic
                  </div>
                )}
              </div>

              {/* Speed & ETA */}
              <div className="mt-4 grid grid-cols-2 gap-3">
                <div className="rounded-lg bg-slate-50 p-3.5">
                  <p className="flex items-center gap-1.5 text-xs font-medium text-slate-500">
                    <Gauge className="h-3.5 w-3.5 text-orange-600" /> Current Speed
                  </p>
                  <p className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
                    {speedKmh} km/h
                  </p>
                </div>
                <div className="rounded-lg bg-slate-50 p-3.5">
                  <p className="flex items-center gap-1.5 text-xs font-medium text-slate-500">
                    <Clock className="h-3.5 w-3.5 text-emerald-600" /> Next Stop ETA
                  </p>
                  <p className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
                    {remainingEtaMins} mins
                  </p>
                </div>
              </div>

              {/* Coordinates & Stops */}
              <div className="mt-4 space-y-3 border-t border-slate-100 pt-4 text-xs">
                <div className="flex items-start gap-2.5">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-orange-600" />
                  <div>
                    <p className="text-slate-500">Current Location</p>
                    <p className="font-semibold text-slate-900">Near {startStop?.name}</p>
                    <p className="mt-0.5 font-mono text-[11px] text-slate-500 tabular-nums">
                      {currentPosition.lat.toFixed(4)}° N, {currentPosition.lng.toFixed(4)}° E
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                  <div>
                    <p className="text-slate-500">Next Scheduled Stop</p>
                    <p className="font-semibold text-slate-900">{nextStop?.name}</p>
                  </div>
                </div>
              </div>

              {/* Driver Contact */}
              <div className="mt-5 flex items-center justify-between rounded-lg bg-slate-900 px-4 py-3 text-white">
                <div>
                  <p className="text-[11px] text-slate-400">Driver & Crew Contact</p>
                  <p className="text-sm font-bold">{trackingData.driverName}</p>
                </div>
                <a
                  href={`tel:${trackingData.driverPhone}`}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700"
                >
                  <Phone className="h-3.5 w-3.5" /> Call Crew
                </a>
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
