import { CheckCircle2, Navigation, Printer } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { useBookingStore } from '../store/useBookingStore';

export function TicketPage() {
  const { activeTicketPnr, bookings, navigate } = useBookingStore();

  const booking =
    bookings.find((b) => b.pnr === activeTicketPnr) || bookings[0];

  if (!booking) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <h2 className="font-display text-xl font-bold text-slate-900">Ticket Not Found</h2>
        <p className="mt-2 text-sm text-slate-500">
          No e-ticket record was found. View your active trips in My Bookings.
        </p>
        <button
          type="button"
          onClick={() => navigate('bookings')}
          className="mt-4 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white cursor-pointer"
        >
          Go to My Bookings
        </button>
      </div>
    );
  }

  const qrPayload = JSON.stringify({
    pnr: booking.pnr,
    bus: booking.busNumber,
    route: `${booking.origin}-${booking.destination}`,
    date: booking.travelDate,
    seats: booking.seats,
  });

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
      {/* Confirmation Action Bar */}
      <div className="no-print mb-6 flex flex-wrap items-center justify-between gap-4 rounded-xl border border-emerald-200 bg-emerald-50 p-4">
        <div className="flex items-center gap-3">
          <CheckCircle2 className="h-7 w-7 shrink-0 text-emerald-600" />
          <div>
            <h1 className="font-display text-base font-bold text-emerald-950">
              E-Ticket Confirmed
            </h1>
            <p className="text-xs text-emerald-800">
              Sent to {booking.contactEmail} · {booking.contactPhone}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => navigate('track', { trackingQuery: booking.pnr })}
            className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 cursor-pointer"
          >
            <Navigation className="h-3.5 w-3.5 text-orange-400" /> Track Live
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 cursor-pointer"
          >
            <Printer className="h-3.5 w-3.5" /> Print / Save PDF
          </button>
        </div>
      </div>

      {/* Printable E-Ticket Card */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
        <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 px-6 py-5 text-white">
          <div>
            <p className="text-xs font-medium text-slate-400">SwiftBus Digital E-Ticket</p>
            <h2 className="font-display mt-0.5 text-lg font-bold">
              {booking.operatorName}
            </h2>
          </div>
          <div className="sm:text-right">
            <p className="text-xs text-slate-400">PNR Number</p>
            <p className="font-mono text-xl font-bold tracking-wider text-orange-400 tabular-nums">
              {booking.pnr}
            </p>
          </div>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 gap-6 border-b border-dashed border-slate-200 pb-6 sm:grid-cols-3">
            <div>
              <p className="text-xs font-semibold text-slate-400 tabular-nums">
                DEPARTURE · {booking.travelDate}
              </p>
              <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
                {booking.departureTime}
              </p>
              <p className="text-sm font-bold text-slate-800">{booking.origin}</p>
              <p className="mt-1 text-xs text-slate-500">
                {booking.boardingPoint.name} ({booking.boardingPoint.landmark})
              </p>
            </div>

            <div className="flex flex-col items-start justify-center sm:items-center">
              <p className="text-xs font-semibold text-slate-700">{booking.busType}</p>
              <p className="mt-1 font-mono text-xs text-slate-500">{booking.busNumber}</p>
            </div>

            <div className="sm:text-right">
              <p className="text-xs font-semibold text-slate-400">ARRIVAL</p>
              <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
                {booking.arrivalTime}
              </p>
              <p className="text-sm font-bold text-slate-800">{booking.destination}</p>
              <p className="mt-1 text-xs text-slate-500">
                {booking.droppingPoint.name} ({booking.droppingPoint.landmark})
              </p>
            </div>
          </div>

          {/* Passengers & QR */}
          <div className="mt-6 grid grid-cols-1 items-center gap-6 sm:grid-cols-12">
            <div className="sm:col-span-8">
              <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-500">
                Passengers
              </h3>
              <div className="divide-y divide-slate-100 rounded-xl border border-slate-200">
                {booking.passengers.map((p) => (
                  <div
                    key={p.seatId}
                    className="flex items-center justify-between px-4 py-3 text-sm"
                  >
                    <div>
                      <span className="font-semibold text-slate-900">{p.name}</span>
                      <span className="ml-2 text-xs text-slate-500">
                        {p.age} yrs · {p.gender}
                      </span>
                    </div>
                    <span className="font-mono text-xs font-bold text-slate-900">
                      Seat {p.seatLabel}
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-4 flex items-center justify-between text-sm font-bold text-slate-900">
                <span>Total Paid ({booking.paymentMethod})</span>
                <span className="font-mono tabular-nums">₹{booking.totalAmount}</span>
              </div>
            </div>

            <div className="flex flex-col items-center justify-center rounded-xl border border-slate-200 bg-slate-50 p-4 sm:col-span-4">
              <QRCodeSVG value={qrPayload} size={120} level="M" />
              <p className="mt-2.5 font-mono text-[11px] font-semibold text-slate-600">
                SCAN AT BOARDING
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
