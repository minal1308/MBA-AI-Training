import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  BatteryCharging,
  Droplets,
  Navigation,
  ShieldCheck,
  SlidersHorizontal,
  Star,
  Wifi,
} from 'lucide-react';
import { SearchWidget } from '../components/SearchWidget';
import { SeatLayoutDrawer } from '../components/SeatLayoutDrawer';
import { useBookingStore } from '../store/useBookingStore';
import type { Bus, BusType } from '../types';

type TimeSlot = 'MORNING' | 'AFTERNOON' | 'EVENING' | 'NIGHT';

function getTimeSlot(time: string): TimeSlot {
  const hour = parseInt(time.split(':')[0], 10);
  if (hour >= 6 && hour < 12) return 'MORNING';
  if (hour >= 12 && hour < 18) return 'AFTERNOON';
  if (hour >= 18 && hour < 22) return 'EVENING';
  return 'NIGHT';
}

export function SearchResultsPage() {
  const {
    searchQuery,
    selectBusForBooking,
    selectedBus,
    resetActiveBooking,
  } = useBookingStore();

  const [buses, setBuses] = useState<Bus[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sortBy, setSortBy] = useState('earliest');

  // Sidebar Filters
  const [selectedSlots, setSelectedSlots] = useState<TimeSlot[]>([]);
  const [selectedTypes, setSelectedTypes] = useState<BusType[]>([]);
  const [maxPrice, setMaxPrice] = useState<number>(1500);
  const [selectedBoarding, setSelectedBoarding] = useState<string>('ALL');
  const [selectedDropping, setSelectedDropping] = useState<string>('ALL');

  const fetchBuses = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const url = `/api/buses?origin=${encodeURIComponent(
        searchQuery.origin
      )}&destination=${encodeURIComponent(searchQuery.destination)}&sortBy=${sortBy}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('Failed to load buses');
      const data = await res.json();
      setBuses(data.buses || []);
    } catch {
      setError('Unable to fetch bus schedules right now. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [searchQuery.origin, searchQuery.destination, sortBy]);

  useEffect(() => {
    fetchBuses();
  }, [fetchBuses]);

  // Reset point filters when corridor changes
  useEffect(() => {
    setSelectedBoarding('ALL');
    setSelectedDropping('ALL');
  }, [searchQuery.origin, searchQuery.destination]);

  const allBoardingNames = useMemo(() => {
    const names = new Set<string>();
    buses.forEach((b) => b.boardingPoints.forEach((bp) => names.add(bp.name)));
    return Array.from(names);
  }, [buses]);

  const allDroppingNames = useMemo(() => {
    const names = new Set<string>();
    buses.forEach((b) => b.droppingPoints.forEach((dp) => names.add(dp.name)));
    return Array.from(names);
  }, [buses]);

  const filteredBuses = useMemo(() => {
    return buses.filter((bus) => {
      if (selectedSlots.length > 0 && !selectedSlots.includes(getTimeSlot(bus.departureTime))) {
        return false;
      }
      if (selectedTypes.length > 0 && !selectedTypes.includes(bus.busType)) {
        return false;
      }
      if (bus.startingPrice > maxPrice) return false;
      if (
        selectedBoarding !== 'ALL' &&
        !bus.boardingPoints.some((bp) => bp.name === selectedBoarding)
      ) {
        return false;
      }
      if (
        selectedDropping !== 'ALL' &&
        !bus.droppingPoints.some((dp) => dp.name === selectedDropping)
      ) {
        return false;
      }
      return true;
    });
  }, [buses, selectedSlots, selectedTypes, maxPrice, selectedBoarding, selectedDropping]);

  const toggleSlot = (slot: TimeSlot) =>
    setSelectedSlots((prev) =>
      prev.includes(slot) ? prev.filter((s) => s !== slot) : [...prev, slot]
    );

  const toggleType = (type: BusType) =>
    setSelectedTypes((prev) =>
      prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
    );

  const resetFilters = () => {
    setSelectedSlots([]);
    setSelectedTypes([]);
    setMaxPrice(1500);
    setSelectedBoarding('ALL');
    setSelectedDropping('ALL');
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
      <div className="mb-6">
        <SearchWidget compact onSearchExecuted={fetchBuses} />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Sidebar Filters */}
        <aside className="lg:col-span-3">
          <div className="sticky top-20 space-y-6 rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <span className="flex items-center gap-2 text-sm font-bold text-slate-900">
                <SlidersHorizontal className="h-4 w-4 text-orange-600" /> Filters
              </span>
              <button
                type="button"
                onClick={resetFilters}
                className="text-xs font-semibold text-orange-600 hover:underline cursor-pointer"
              >
                Reset all
              </button>
            </div>

            {/* Departure Time */}
            <div>
              <h3 className="mb-2.5 text-xs font-bold text-slate-700">Departure Window</h3>
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    { id: 'MORNING', label: '6 AM – 12 PM' },
                    { id: 'AFTERNOON', label: '12 – 6 PM' },
                    { id: 'EVENING', label: '6 – 10 PM' },
                    { id: 'NIGHT', label: 'After 10 PM' },
                  ] as { id: TimeSlot; label: string }[]
                ).map((slot) => (
                  <button
                    key={slot.id}
                    type="button"
                    onClick={() => toggleSlot(slot.id)}
                    className={`rounded-lg border px-2.5 py-2 text-xs font-semibold transition cursor-pointer whitespace-nowrap ${
                      selectedSlots.includes(slot.id)
                        ? 'border-orange-500 bg-orange-50 text-orange-700'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {slot.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Bus Type */}
            <div>
              <h3 className="mb-2.5 text-xs font-bold text-slate-700">Coach Type</h3>
              <div className="space-y-2">
                {(
                  ['AC Sleeper', 'Volvo Multi-Axle', 'AC Seater', 'Non-AC Seater'] as BusType[]
                ).map((type) => (
                  <label key={type} className="flex cursor-pointer items-center gap-2.5 text-sm">
                    <input
                      type="checkbox"
                      checked={selectedTypes.includes(type)}
                      onChange={() => toggleType(type)}
                      className="h-4 w-4 rounded accent-orange-600"
                    />
                    <span className="text-slate-700">{type}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Price Range Slider */}
            <div>
              <div className="mb-2 flex items-center justify-between text-xs font-bold text-slate-700">
                <span>Max Fare</span>
                <span className="font-mono text-orange-700 tabular-nums">₹{maxPrice}</span>
              </div>
              <input
                type="range"
                min={400}
                max={1500}
                step={50}
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                aria-label="Maximum fare filter"
                className="w-full accent-orange-600 cursor-pointer"
              />
              <div className="mt-1 flex justify-between font-mono text-[11px] text-slate-400 tabular-nums">
                <span>₹400</span>
                <span>₹1,500</span>
              </div>
            </div>

            {/* Boarding & Dropping Points */}
            <div className="space-y-3">
              <div>
                <label
                  htmlFor="boarding-filter"
                  className="mb-1.5 block text-xs font-bold text-slate-700"
                >
                  Boarding Point
                </label>
                <select
                  id="boarding-filter"
                  value={selectedBoarding}
                  onChange={(e) => setSelectedBoarding(e.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-700 outline-none focus:border-orange-500"
                >
                  <option value="ALL">All Boarding Points</option>
                  {allBoardingNames.map((name) => (
                    <option key={name} value={name}>
                      {name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="dropping-filter"
                  className="mb-1.5 block text-xs font-bold text-slate-700"
                >
                  Dropping Point
                </label>
                <select
                  id="dropping-filter"
                  value={selectedDropping}
                  onChange={(e) => setSelectedDropping(e.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-700 outline-none focus:border-orange-500"
                >
                  <option value="ALL">All Dropping Points</option>
                  {allDroppingNames.map((name) => (
                    <option key={name} value={name}>
                      {name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </aside>

        {/* Results Column */}
        <section className="lg:col-span-9">
          {/* Header & Sort Bar */}
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-5 py-3.5">
            <div>
              <h1 className="font-display text-lg font-bold text-slate-900">
                {searchQuery.origin} to {searchQuery.destination}
              </h1>
              <p className="text-xs text-slate-500 tabular-nums">
                {searchQuery.travelDate} · {filteredBuses.length} coaches available
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-1.5 rounded-lg bg-slate-100 p-1">
              {[
                { id: 'earliest', label: 'Earliest' },
                { id: 'cheapest', label: 'Cheapest' },
                { id: 'fastest', label: 'Fastest' },
                { id: 'rating', label: 'Highest Rated' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setSortBy(opt.id)}
                  className={`rounded-md px-3 py-1.5 text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer ${
                    sortBy === opt.id
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <div className="mb-4 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm font-medium text-rose-800">
              {error}
            </div>
          )}

          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="h-40 animate-pulse rounded-xl border border-slate-200 bg-white p-5"
                >
                  <div className="h-5 w-1/3 rounded bg-slate-200" />
                  <div className="mt-4 h-4 w-2/3 rounded bg-slate-100" />
                  <div className="mt-6 h-8 w-32 rounded bg-slate-200" />
                </div>
              ))}
            </div>
          ) : filteredBuses.length === 0 ? (
            <div className="rounded-xl border border-dashed border-slate-300 bg-white p-12 text-center">
              <p className="font-display text-base font-bold text-slate-900">
                No coaches match your current filters
              </p>
              <p className="mt-1 text-sm text-slate-500">
                Try resetting filters or searching popular corridors like Mumbai to Pune or Bangalore to Chennai.
              </p>
              <button
                type="button"
                onClick={resetFilters}
                className="mt-4 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredBuses.map((bus) => (
                <article
                  key={bus.id}
                  className="rounded-xl border border-slate-200 bg-white p-5 transition hover:border-slate-300"
                >
                  <div className="grid grid-cols-1 items-center gap-5 md:grid-cols-12">
                    {/* Operator & Clean Metadata */}
                    <div className="md:col-span-4">
                      <h2 className="font-display text-base font-bold text-slate-900">
                        {bus.operatorName}
                      </h2>
                      <p className="mt-1 text-xs text-slate-500">
                        {bus.busType} · <span className="font-mono">{bus.busNumber}</span>
                      </p>
                      <div className="mt-2.5 flex flex-wrap items-center gap-2 text-xs tabular-nums">
                        <span className="inline-flex items-center gap-1 font-bold text-emerald-700">
                          <Star className="h-3.5 w-3.5 fill-emerald-600 text-emerald-600" />
                          {bus.rating}
                        </span>
                        <span className="text-slate-400">({bus.reviewsCount})</span>
                        {bus.zeroCancellation && (
                          <>
                            <span aria-hidden="true" className="text-slate-300">·</span>
                            <span className="inline-flex items-center gap-1 font-medium text-sky-700">
                              <ShieldCheck className="h-3.5 w-3.5" /> Free Cancel
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Schedule Timings */}
                    <div className="flex items-center justify-between md:col-span-4">
                      <div>
                        <p className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                          {bus.departureTime}
                        </p>
                        <p className="text-xs text-slate-500">{bus.origin}</p>
                      </div>
                      <div className="px-3 text-center">
                        <p className="font-mono text-[11px] font-medium text-slate-500 tabular-nums">
                          {bus.duration}
                        </p>
                        <div className="my-1.5 h-px w-16 bg-slate-300" />
                      </div>
                      <div className="text-right">
                        <p className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                          {bus.arrivalTime}
                        </p>
                        <p className="text-xs text-slate-500">{bus.destination}</p>
                      </div>
                    </div>

                    {/* Fare & Action */}
                    <div className="flex items-center justify-between border-t border-slate-100 pt-3 md:col-span-4 md:flex-col md:items-end md:border-none md:pt-0">
                      <div className="md:text-right">
                        <p className="text-xs text-slate-500">Starts at</p>
                        <p className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
                          ₹{bus.startingPrice}
                        </p>
                        <p className="text-xs font-semibold text-emerald-700 tabular-nums">
                          {bus.seatsAvailable} seats left
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => selectBusForBooking(bus)}
                        className="mt-2 rounded-xl bg-orange-600 px-5 py-2.5 text-xs font-semibold text-white transition hover:bg-orange-700 whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        Select Seats
                      </button>
                    </div>
                  </div>

                  {/* Amenities Strip */}
                  <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-slate-100 pt-3 text-xs text-slate-500">
                    {bus.amenities.includes('Wi-Fi') && (
                      <span className="inline-flex items-center gap-1.5">
                        <Wifi className="h-3.5 w-3.5 text-slate-400" /> Wi-Fi
                      </span>
                    )}
                    {bus.amenities.includes('Charging Point') && (
                      <span className="inline-flex items-center gap-1.5">
                        <BatteryCharging className="h-3.5 w-3.5 text-slate-400" /> Charging Point
                      </span>
                    )}
                    {bus.amenities.includes('Water Bottle') && (
                      <span className="inline-flex items-center gap-1.5">
                        <Droplets className="h-3.5 w-3.5 text-slate-400" /> Water Bottle
                      </span>
                    )}
                    {bus.amenities.includes('Live GPS') && (
                      <span className="inline-flex items-center gap-1.5 font-medium text-emerald-700">
                        <Navigation className="h-3.5 w-3.5" /> Live GPS Trackable
                      </span>
                    )}
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>

      {selectedBus && (
        <SeatLayoutDrawer bus={selectedBus} onClose={() => resetActiveBooking()} />
      )}
    </div>
  );
}
