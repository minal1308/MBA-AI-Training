import { useState } from 'react';
import {
  ArrowLeft,
  Building2,
  CreditCard,
  Loader2,
  ShieldCheck,
  Smartphone,
  Tag,
} from 'lucide-react';
import { useBookingStore } from '../store/useBookingStore';

export function CheckoutPage() {
  const {
    selectedBus,
    selectedSeats,
    selectedBoardingPoint,
    selectedDroppingPoint,
    passengers,
    contactEmail,
    contactPhone,
    appliedPromoCode,
    discountAmount,
    updatePassenger,
    setContactInfo,
    applyPromo,
    removePromo,
    confirmBooking,
    navigate,
    addToast,
  } = useBookingStore();

  const [promoInput, setPromoInput] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'CARD' | 'NETBANKING'>('UPI');
  const [upiId, setUpiId] = useState('traveler@okicici');
  const [processing, setProcessing] = useState(false);

  if (!selectedBus || selectedSeats.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <h2 className="font-display text-xl font-bold text-slate-900">No seats selected</h2>
        <p className="mt-2 text-sm text-slate-500">
          Select a coach and choose at least one seat before proceeding to passenger checkout.
        </p>
        <button
          type="button"
          onClick={() => navigate('search')}
          className="mt-5 inline-flex items-center gap-2 rounded-xl bg-orange-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-700 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" /> Browse Buses
        </button>
      </div>
    );
  }

  const baseFare = selectedSeats.reduce((sum, s) => sum + s.price, 0);
  const gstAmount = Math.round(baseFare * 0.05);
  const totalAmount = Math.max(0, baseFare + gstAmount - discountAmount);

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    const invalidPassenger = passengers.some((p) => !p.name.trim() || !p.age.trim());
    if (invalidPassenger || !contactEmail.trim() || !contactPhone.trim()) {
      addToast('error', 'Please complete all passenger and contact fields.');
      return;
    }

    setProcessing(true);
    setTimeout(async () => {
      const booking = await confirmBooking(paymentMethod);
      setProcessing(false);
      addToast('success', `Booking confirmed. PNR: ${booking.pnr}`);
      navigate('ticket', { pnr: booking.pnr });
    }, 1200);
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Passenger Details & Checkout
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Complete passenger names matching government ID for boarding verification.
          </p>
        </div>
        <button
          type="button"
          onClick={() => navigate('search')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" /> Back to Buses
        </button>
      </div>

      <form onSubmit={handleCheckout} className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Passenger, Contact & Payment */}
        <div className="space-y-6 lg:col-span-8">
          <section className="rounded-xl border border-slate-200 bg-white p-6">
            <h2 className="font-display mb-4 text-base font-bold text-slate-900">
              Passenger Manifest ({passengers.length} {passengers.length === 1 ? 'Seat' : 'Seats'})
            </h2>
            <div className="divide-y divide-slate-200">
              {passengers.map((p, index) => (
                <div key={p.seatId} className="py-4 first:pt-0 last:pb-0">
                  <div className="mb-3 flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700">
                      Passenger {index + 1}
                    </span>
                    <span className="font-mono font-bold text-emerald-700">
                      Seat {p.seatLabel}
                    </span>
                  </div>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-12">
                    <input
                      type="text"
                      required
                      placeholder="Full Name"
                      value={p.name}
                      onChange={(e) => updatePassenger(p.seatId, 'name', e.target.value)}
                      className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm outline-none focus:border-orange-500 focus:bg-white sm:col-span-6"
                    />
                    <input
                      type="number"
                      required
                      min={1}
                      max={100}
                      placeholder="Age"
                      value={p.age}
                      onChange={(e) => updatePassenger(p.seatId, 'age', e.target.value)}
                      className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm tabular-nums outline-none focus:border-orange-500 focus:bg-white sm:col-span-3"
                    />
                    <select
                      value={p.gender}
                      onChange={(e) => updatePassenger(p.seatId, 'gender', e.target.value)}
                      className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm outline-none focus:border-orange-500 focus:bg-white sm:col-span-3"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-xl border border-slate-200 bg-white p-6">
            <h2 className="font-display mb-1 text-base font-bold text-slate-900">
              Ticket Delivery Contact
            </h2>
            <p className="mb-4 text-xs text-slate-500">
              Your E-Ticket QR code and Live GPS tracking link will be sent here.
            </p>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <input
                type="email"
                required
                placeholder="Email Address"
                value={contactEmail}
                onChange={(e) => setContactInfo(e.target.value, contactPhone)}
                className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm outline-none focus:border-orange-500 focus:bg-white"
              />
              <input
                type="tel"
                required
                placeholder="WhatsApp / Mobile Number"
                value={contactPhone}
                onChange={(e) => setContactInfo(contactEmail, e.target.value)}
                className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm tabular-nums outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>
          </section>

          <section className="rounded-xl border border-slate-200 bg-white p-6">
            <h2 className="font-display mb-4 flex items-center gap-2 text-base font-bold text-slate-900">
              <ShieldCheck className="h-5 w-5 text-emerald-600" /> Payment Method
            </h2>

            <div className="mb-4 grid grid-cols-3 gap-2">
              {[
                { id: 'UPI', label: 'UPI / QR', icon: Smartphone },
                { id: 'CARD', label: 'Credit / Debit', icon: CreditCard },
                { id: 'NETBANKING', label: 'Net Banking', icon: Building2 },
              ].map((m) => {
                const Icon = m.icon;
                const active = paymentMethod === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setPaymentMethod(m.id as 'UPI' | 'CARD' | 'NETBANKING')}
                    className={`flex flex-col items-center gap-1.5 rounded-lg border p-3 text-xs font-semibold transition cursor-pointer ${
                      active
                        ? 'border-orange-500 bg-orange-50 text-orange-700'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    {m.label}
                  </button>
                );
              })}
            </div>

            {paymentMethod === 'UPI' && (
              <div className="rounded-lg bg-slate-50 p-4">
                <label
                  htmlFor="upi-id"
                  className="mb-1.5 block text-xs font-semibold text-slate-600"
                >
                  Enter UPI ID (GPay, PhonePe, Paytm)
                </label>
                <input
                  id="upi-id"
                  type="text"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-sm outline-none focus:border-orange-500"
                />
              </div>
            )}

            {paymentMethod === 'CARD' && (
              <div className="grid grid-cols-2 gap-3 rounded-lg bg-slate-50 p-4">
                <input
                  type="text"
                  defaultValue="4532 •••• •••• 8891"
                  aria-label="Card number"
                  className="col-span-2 rounded-lg border border-slate-200 bg-white px-3.5 py-2 font-mono text-sm"
                />
                <input
                  type="text"
                  defaultValue="09/29"
                  aria-label="Card expiry"
                  className="rounded-lg border border-slate-200 bg-white px-3.5 py-2 font-mono text-sm"
                />
                <input
                  type="password"
                  defaultValue="123"
                  aria-label="Card CVV"
                  className="rounded-lg border border-slate-200 bg-white px-3.5 py-2 font-mono text-sm"
                />
              </div>
            )}

            {paymentMethod === 'NETBANKING' && (
              <div className="rounded-lg bg-slate-50 p-4">
                <label
                  htmlFor="netbank-select"
                  className="mb-1.5 block text-xs font-semibold text-slate-600"
                >
                  Select Bank
                </label>
                <select
                  id="netbank-select"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-sm"
                >
                  <option>HDFC Bank</option>
                  <option>ICICI Bank</option>
                  <option>State Bank of India</option>
                  <option>Axis Bank</option>
                </select>
              </div>
            )}
          </section>
        </div>

        {/* Right: Trip Summary & Fare Breakdown */}
        <aside className="lg:col-span-4">
          <div className="sticky top-20 rounded-xl border border-slate-200 bg-white p-6">
            <h3 className="font-display text-base font-bold text-slate-900">
              {selectedBus.operatorName}
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              {selectedBus.origin} to {selectedBus.destination} · {selectedBus.busType}
            </p>

            <div className="my-4 space-y-2 border-y border-slate-100 py-3.5 text-xs text-slate-600">
              <p>
                <span className="font-semibold text-slate-800">Boarding:</span>{' '}
                {selectedBoardingPoint?.name} ({selectedBoardingPoint?.time})
              </p>
              <p>
                <span className="font-semibold text-slate-800">Dropping:</span>{' '}
                {selectedDroppingPoint?.name} ({selectedDroppingPoint?.time})
              </p>
              <p>
                <span className="font-semibold text-slate-800">Seats:</span>{' '}
                <span className="font-mono font-bold text-slate-900">
                  {selectedSeats.map((s) => s.label).join(', ')}
                </span>
              </p>
            </div>

            {/* Promo Code */}
            <div className="mb-5">
              <label
                htmlFor="promo-code-input"
                className="mb-1.5 flex items-center gap-1.5 text-xs font-bold text-slate-700"
              >
                <Tag className="h-3.5 w-3.5 text-orange-600" /> Promo Code
              </label>
              {appliedPromoCode ? (
                <div className="flex items-center justify-between rounded-lg bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-800">
                  <span>
                    {appliedPromoCode} applied (-₹{discountAmount})
                  </span>
                  <button
                    type="button"
                    onClick={removePromo}
                    className="font-semibold text-rose-600 hover:underline cursor-pointer"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <input
                    id="promo-code-input"
                    type="text"
                    value={promoInput}
                    onChange={(e) => setPromoInput(e.target.value)}
                    placeholder="FIRST20 / WEEKEND10"
                    className="flex-1 rounded-lg border border-slate-200 px-3 py-2 font-mono text-xs uppercase outline-none focus:border-orange-500"
                  />
                  <button
                    type="button"
                    onClick={() => applyPromo(promoInput)}
                    className="rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 cursor-pointer"
                  >
                    Apply
                  </button>
                </div>
              )}
            </div>

            {/* Itemized Fare */}
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-slate-600">
                <span>Base Fare ({selectedSeats.length} seats)</span>
                <span className="font-mono tabular-nums">₹{baseFare}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>GST & Service Tax (5%)</span>
                <span className="font-mono tabular-nums">₹{gstAmount}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between font-semibold text-emerald-700">
                  <span>Promo Discount</span>
                  <span className="font-mono tabular-nums">-₹{discountAmount}</span>
                </div>
              )}
              <div className="flex justify-between border-t border-slate-200 pt-3 text-lg font-bold text-slate-900">
                <span>Total Payable</span>
                <span className="font-mono tabular-nums">₹{totalAmount}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={processing}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 py-3.5 text-sm font-semibold text-white transition hover:bg-emerald-700 disabled:opacity-70 cursor-pointer"
            >
              {processing ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Confirming Payment...
                </>
              ) : (
                `Pay ₹${totalAmount} & Confirm`
              )}
            </button>
          </div>
        </aside>
      </form>
    </div>
  );
}
