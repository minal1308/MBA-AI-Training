import { ArrowRight, Copy, Search } from 'lucide-react';
import { POPULAR_ROUTES, PROMO_CODES } from '../data/mockData';
import { useBookingStore } from '../store/useBookingStore';
import { SearchWidget } from '../components/SearchWidget';

const HERO_IMG = '/src/assets/images/hero_coach_highway_1795250680223.jpg';
const CABIN_IMG = '/src/assets/images/sleeper_cabin_interior_1795250679958.jpg';
const TERMINAL_IMG = '/src/assets/images/city_terminal_hub_1795250679985.jpg';

export function LandingPage() {
  const { setSearchQuery, navigate, addToast } = useBookingStore();

  const handleQuickRoute = (origin: string, destination: string) => {
    setSearchQuery({ origin, destination });
    navigate('search');
  };

  const copyPromo = (code: string) => {
    navigator.clipboard?.writeText(code);
    addToast('success', `Promo code ${code} copied to clipboard.`);
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-slate-950 text-white">
        <img
          src={HERO_IMG}
          alt="Modern intercity coach cruising along an elevated expressway at dawn"
          referrerPolicy="no-referrer"
          className="absolute inset-0 h-full w-full object-cover opacity-55"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-b from-slate-950/75 via-slate-950/70 to-slate-950/90"
        />

        <div className="relative mx-auto max-w-7xl px-4 pb-16 pt-14 sm:px-6 sm:pb-20 sm:pt-20">
          <div className="mb-8 max-w-2xl">
            <p className="text-xs font-semibold uppercase tracking-wider text-orange-400">
              Verified Intercity Mobility · Real-Time Highway Telemetry
            </p>
            <h1 className="font-display mt-3 text-[clamp(2.25rem,4vw,3.75rem)] font-extrabold leading-[1.08] tracking-tight text-balance text-white">
              Intercity bus travel with live GPS clarity.
            </h1>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-slate-200">
              Reserve exact sleeper berths, board from mapped city landmarks, and share live highway arrival telemetry with zero cancellation surprises.
            </p>
          </div>

          <SearchWidget />

          <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-slate-300 tabular-nums">
            <span>4,200+ daily express departures</span>
            <span aria-hidden="true">·</span>
            <span>4.7/5 verified rider punctuality</span>
            <span aria-hidden="true">·</span>
            <span>Instant 100% refund on eligible routes</span>
          </div>
        </div>
      </section>

      {/* Capabilities & Fleet Showcase */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="grid grid-cols-1 items-stretch gap-8 lg:grid-cols-12">
          <div className="flex flex-col justify-between space-y-6 lg:col-span-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-orange-600">
                Built for Predictable Journeys
              </p>
              <h2 className="font-display mt-2 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl text-balance">
                Every mile tracked, every berth verified before you board.
              </h2>
            </div>

            <div className="divide-y divide-slate-200 border-y border-slate-200">
              <div className="py-4">
                <h3 className="font-display text-base font-bold text-slate-900">
                  01. Live Highway GPS Telemetry
                </h3>
                <p className="mt-1 text-sm text-slate-600">
                  Track exact coach coordinates, current speed, next intermediate stop, and real-time delay status directly from your PNR.
                </p>
              </div>
              <div className="py-4">
                <h3 className="font-display text-base font-bold text-slate-900">
                  02. Zero-Fee Flexible Cancellations
                </h3>
                <p className="mt-1 text-sm text-slate-600">
                  Plans shift. Cancel eligible trips up to 12 hours prior to departure with transparent, automated refund previews.
                </p>
              </div>
              <div className="py-4">
                <h3 className="font-display text-base font-bold text-slate-900">
                  03. Verified Multi-Axle & Sleeper Coaches
                </h3>
                <p className="mt-1 text-sm text-slate-600">
                  Visual Upper & Lower deck seat maps with dedicated Ladies-Only indicators, boarding landmarks, and crew contact numbers.
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:col-span-6">
            <div className="relative overflow-hidden rounded-2xl border border-slate-200 bg-slate-900 min-h-[260px]">
              <img
                src={CABIN_IMG}
                alt="Modern AC sleeper cabin interior with reading lamp and charging port"
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/90 via-slate-950/50 to-transparent p-4 text-white">
                <p className="text-xs font-semibold text-orange-300">2+1 AC Sleeper Berths</p>
                <p className="mt-0.5 text-sm font-bold">
                  Individual reading lamps, curtains, and USB power at every berth.
                </p>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-2xl border border-slate-200 bg-slate-900 min-h-[260px]">
              <img
                src={TERMINAL_IMG}
                alt="Modern glass intercity bus terminal hub at twilight"
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/90 via-slate-950/50 to-transparent p-4 text-white">
                <p className="text-xs font-semibold text-emerald-300">Mapped Boarding Bays</p>
                <p className="mt-0.5 text-sm font-bold">
                  Exact bay timestamps and landmark notes across 120+ pickup points.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Seasonal Promo Codes Carousel */}
      <section className="border-y border-slate-200 bg-white py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="mb-6 flex flex-wrap items-end justify-between gap-2">
            <div>
              <h2 className="font-display text-xl font-bold text-slate-900 sm:text-2xl">
                Seasonal Offers & Promo Codes
              </h2>
              <p className="mt-1 text-sm text-slate-500">
                Apply any code at checkout for instant fare savings.
              </p>
            </div>
            <span className="text-xs font-medium text-slate-500">Tap a code to copy</span>
          </div>

          <div className="flex gap-4 overflow-x-auto pb-2 md:grid md:grid-cols-3">
            {PROMO_CODES.map((promo) => (
              <div
                key={promo.code}
                className="flex min-w-[270px] flex-col justify-between rounded-xl border border-slate-200 bg-[#F8FAFC] p-5 transition hover:border-slate-300"
              >
                <div>
                  <p className="text-xs font-semibold text-orange-600">
                    {promo.tag} · Up to ₹{promo.maxDiscount} off
                  </p>
                  <h3 className="font-display mt-1.5 text-base font-bold text-slate-900">
                    {promo.title}
                  </h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-slate-600">
                    {promo.description}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => copyPromo(promo.code)}
                  className="mt-4 flex w-full items-center justify-between rounded-lg border border-dashed border-slate-300 bg-white px-3.5 py-2.5 font-mono text-xs font-bold text-slate-900 transition hover:border-orange-500 hover:text-orange-700 cursor-pointer"
                >
                  <span>{promo.code}</span>
                  <span className="inline-flex items-center gap-1.5 font-sans text-xs font-semibold text-orange-600">
                    <Copy className="h-3.5 w-3.5" /> Copy
                  </span>
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Intercity Corridors */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="font-display text-xl font-bold text-slate-900 sm:text-2xl">
              Popular Intercity Corridors
            </h2>
            <p className="mt-1 text-sm text-slate-500">
              Select a corridor to inspect live departures and seat availability.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('search')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-orange-600 hover:text-orange-700 cursor-pointer"
          >
            <Search className="h-4 w-4" /> Browse All Routes
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {POPULAR_ROUTES.map((route) => (
            <button
              key={`${route.origin}-${route.destination}`}
              type="button"
              onClick={() => handleQuickRoute(route.origin, route.destination)}
              className="group rounded-xl border border-slate-200 bg-white p-5 text-left transition hover:border-slate-900 cursor-pointer"
            >
              <div className="flex items-center justify-between text-base font-bold text-slate-900">
                <span>{route.origin}</span>
                <ArrowRight className="h-4 w-4 text-orange-600 transition group-hover:translate-x-1" />
                <span>{route.destination}</span>
              </div>
              <p className="mt-2 text-xs text-slate-500 tabular-nums">
                {route.busesCount} daily buses · Avg {route.duration}
              </p>
              <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
                <span className="text-xs text-slate-500">Fares from</span>
                <span className="font-mono text-base font-bold text-emerald-700 tabular-nums">
                  ₹{route.startingPrice}
                </span>
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
