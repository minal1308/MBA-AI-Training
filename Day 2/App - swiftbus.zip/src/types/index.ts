export type BusType = 'AC Sleeper' | 'Volvo Multi-Axle' | 'AC Seater' | 'Non-AC Seater';
export type DeckLayout = '2+1_SLEEPER' | '2+2_SEATER';
export type SeatStatus = 'AVAILABLE' | 'BOOKED' | 'LADIES';
export type Amenity = 'Wi-Fi' | 'Charging Point' | 'Water Bottle' | 'Blanket' | 'Live GPS' | 'CCTV';

export interface RoutePoint {
  id: string;
  name: string;
  landmark: string;
  time: string;
}

export interface RouteCoordinate {
  name: string;
  lat: number;
  lng: number;
  etaFromStartMins: number;
}

export interface SeatItem {
  id: string;
  label: string;
  deck: 'LOWER' | 'UPPER';
  row: number;
  col: number;
  isSleeper: boolean;
  price: number;
  status: SeatStatus;
}

export interface Bus {
  id: string;
  busNumber: string;
  operatorName: string;
  busType: BusType;
  layoutType: DeckLayout;
  origin: string;
  destination: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  durationMinutes: number;
  rating: number;
  reviewsCount: number;
  startingPrice: number;
  seatsAvailable: number;
  amenities: Amenity[];
  zeroCancellation: boolean;
  boardingPoints: RoutePoint[];
  droppingPoints: RoutePoint[];
  seats: SeatItem[];
  routeCoordinates: RouteCoordinate[];
  driverName: string;
  driverPhone: string;
  currentDelayMins: number;
}

export interface Passenger {
  seatId: string;
  seatLabel: string;
  name: string;
  age: string;
  gender: 'Male' | 'Female' | 'Other';
}

export type BookingStatus = 'UPCOMING' | 'COMPLETED' | 'CANCELLED';

export interface BookingRecord {
  pnr: string;
  busId: string;
  busNumber: string;
  operatorName: string;
  busType: BusType;
  origin: string;
  destination: string;
  travelDate: string;
  departureTime: string;
  arrivalTime: string;
  boardingPoint: RoutePoint;
  droppingPoint: RoutePoint;
  seats: string[];
  passengers: Passenger[];
  contactEmail: string;
  contactPhone: string;
  baseFare: number;
  gstAmount: number;
  discountAmount: number;
  totalAmount: number;
  paymentMethod: string;
  status: BookingStatus;
  refundAmount?: number;
  zeroCancellation: boolean;
  createdAt: string;
}

export interface PromoCode {
  code: string;
  title: string;
  description: string;
  discountPercent: number;
  maxDiscount: number;
  tag: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

export interface TrackingPayload {
  pnr: string | null;
  busNumber: string;
  operatorName: string;
  busType: BusType;
  origin: string;
  destination: string;
  departureTime: string;
  arrivalTime: string;
  driverName: string;
  driverPhone: string;
  currentDelayMins: number;
  routeCoordinates: RouteCoordinate[];
}

export type AppPage = 'home' | 'search' | 'checkout' | 'ticket' | 'track' | 'bookings';
